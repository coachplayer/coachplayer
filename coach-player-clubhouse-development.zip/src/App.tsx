import { AnimatePresence, motion } from "framer-motion";
import type { LucideIcon } from "lucide-react";
import {
  Activity,
  ArrowRight,
  AudioLines,
  Award,
  Banknote,
  BarChart3,
  Bell,
  Bot,
  BriefcaseBusiness,
  CalendarClock,
  CalendarDays,
  Captions,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clapperboard,
  CircleHelp,
  ClipboardCheck,
  Clock3,
  Copy,
  CreditCard,
  Dumbbell,
  Eye,
  EyeOff,
  ExternalLink,
  FileCheck2,
  FileText,
  Gem,
  GraduationCap,
  ImageIcon,
  LayoutDashboard,
  LayoutTemplate,
  Link2,
  ListVideo,
  LockKeyhole,
  MapPin,
  Menu,
  MessageSquare,
  Mic,
  MonitorPlay,
  Package,
  Pencil,
  Play,
  Plus,
  RefreshCw,
  ReceiptText,
  Search,
  Send,
  Settings,
  Share2,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Target,
  ThumbsUp,
  Trash2,
  TrendingUp,
  Users,
  UserRound,
  Video,
  WalletCards,
  X,
} from "lucide-react";
import { FormEvent, useEffect, useMemo, useState } from "react";

type View = "overview" | "pricing" | "growth" | "finance" | "sponsors" | "documents" | "meetings" | "store" | "player" | "coach" | "career" | "studio";
type Toast = { message: string; id: number } | null;

const navigation: { label: string; icon: LucideIcon; view: View }[] = [
  { label: "Club overview", icon: LayoutDashboard, view: "overview" },
  { label: "Plans and pricing", icon: CreditCard, view: "pricing" },
  { label: "3 revenue engines", icon: Activity, view: "growth" },
  { label: "AI Finance Coach", icon: WalletCards, view: "finance" },
  { label: "Sponsor Finder", icon: Search, view: "sponsors" },
  { label: "Club Document AI", icon: FileText, view: "documents" },
  { label: "Club meetings", icon: Video, view: "meetings" },
  { label: "Club store", icon: ShoppingBag, view: "store" },
  { label: "AI Video Studio", icon: Clapperboard, view: "studio" },
];

const coachingNavigation: { label: string; icon: LucideIcon; view: View }[] = [
  { label: "AI Coach Player", icon: Dumbbell, view: "player" },
  { label: "AI Coach Pro", icon: Target, view: "coach" },
  { label: "Career & Development", icon: BriefcaseBusiness, view: "career" },
];

const money = new Intl.NumberFormat("en-ZA", {
  style: "currency",
  currency: "ZAR",
  minimumFractionDigits: 0,
});

function CoachPlayerMark({ compact = false }: { compact?: boolean }) {
  return (
    <span className={`cp-mark ${compact ? "cp-mark-compact" : ""}`} aria-label="Coach Player Clubhouse">
      <span className="cp-mark-word">COACH</span>
      <svg className="cp-mark-figure" viewBox="0 0 52 72" aria-hidden="true">
        <circle cx="26" cy="11" r="9" />
        <path d="M16 26c0-6 4.6-10 10-10s10 4 10 10v22l5 17h-9l-4-14h-4l-4 14h-9l5-17V26Z" />
      </svg>
      <span className="cp-mark-word">PLAYER</span>
    </span>
  );
}

function PageHeading({ eyebrow, title, children }: { eyebrow: string; title: string; children?: React.ReactNode }) {
  return (
    <div className="page-heading">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h1>{title}</h1>
      </div>
      {children}
    </div>
  );
}

function Metric({ label, value, detail, tone = "plain" }: { label: string; value: string; detail: string; tone?: "plain" | "gold" | "wine" }) {
  return (
    <div className={`metric metric-${tone}`}>
      <p>{label}</p>
      <strong>{value}</strong>
      <span>{detail}</span>
    </div>
  );
}

function VerifiedTag({ children }: { children: React.ReactNode }) {
  return <span className="verified-tag"><ShieldCheck size={13} />{children}</span>;
}

function Disclaimer({ children }: { children: React.ReactNode }) {
  return <p className="disclaimer"><CircleHelp size={14} />{children}</p>;
}

function Overview({ navigate }: { navigate: (view: View) => void }) {
  return (
    <div className="page-stack">
      <section className="welcome-panel">
        <div className="welcome-copy">
          <p className="eyebrow eyebrow-gold">Coach Player Clubhouse</p>
          <h1>Build your club&apos;s digital clubhouse for free.</h1>
          <p>Start with the essentials at R0. Then use payments, sponsors, a store and optional AI tools to help your club grow.</p>
          <div className="welcome-actions">
            <button type="button" className="button button-gold" onClick={() => navigate("pricing")}>Create clubhouse - FREE <ArrowRight size={17} /></button>
            <button type="button" className="button button-ghost" onClick={() => navigate("growth")}>See how it grows</button>
          </div>
        </div>
        <blockquote>
          <span>“</span>
          The best gift<br />I can give<br />is myself.
          <small>Coach Player Clubhouse</small>
        </blockquote>
      </section>

      <section className="metrics-grid">
        <Metric label="Available cash" value={money.format(48250)} detail="Updated today" tone="wine" />
        <Metric label="Membership due" value={money.format(12600)} detail="18 outstanding payments" />
        <Metric label="Store revenue" value={money.format(8650)} detail="Up 18% this month" tone="gold" />
        <Metric label="Active sponsors" value="03" detail="2 follow-ups due" />
      </section>

      <section className="content-grid content-grid-wide">
        <div className="surface action-surface">
          <div className="surface-heading">
            <div>
              <p className="eyebrow">Action centre</p>
              <h2>What needs your attention</h2>
            </div>
            <button className="text-button" onClick={() => navigate("finance")}>View finance <ChevronRight size={16} /></button>
          </div>
          <div className="action-list">
            <button onClick={() => navigate("finance")} className="action-row">
              <span className="action-icon action-icon-wine"><ReceiptText size={19} /></span>
              <span><strong>18 membership payments are outstanding</strong><small>AI Finance Coach can prepare a friendly reminder.</small></span>
              <ArrowRight size={18} />
            </button>
            <button onClick={() => navigate("sponsors")} className="action-row">
              <span className="action-icon action-icon-gold"><Sparkles size={19} /></span>
              <span><strong>2 sponsorship opportunities need a follow-up</strong><small>One proposal is ready to send after approval.</small></span>
              <ArrowRight size={18} />
            </button>
            <button onClick={() => navigate("meetings")} className="action-row">
              <span className="action-icon action-icon-ink"><CalendarDays size={19} /></span>
              <span><strong>Committee meeting tomorrow at 18:30</strong><small>Agenda has 4 unassigned items.</small></span>
              <ArrowRight size={18} />
            </button>
            <button onClick={() => navigate("studio")} className="action-row">
              <span className="action-icon action-icon-gold"><Clapperboard size={19} /></span>
              <span><strong>Your next educational video is ready for review</strong><small>AI Video Studio prepared a script, storyboard and thumbnail.</small></span>
              <ArrowRight size={18} />
            </button>
          </div>
        </div>

        <aside className="surface club-pulse">
          <p className="eyebrow">Club pulse</p>
          <h2>Riverside Rugby Club</h2>
          <div className="pulse-score"><span>84</span><small>Club health score</small></div>
          <div className="pulse-bars">
            <div><span>Finance</span><i><b style={{ width: "82%" }} /></i><em>82</em></div>
            <div><span>Attendance</span><i><b style={{ width: "90%" }} /></i><em>90</em></div>
            <div><span>Growth</span><i><b style={{ width: "70%" }} /></i><em>70</em></div>
          </div>
        </aside>
      </section>

      <section className="platform-strip">
        <div><Users size={26} /><strong>Free essentials</strong><span>Website, members, teams, schedules, attendance and a basic store with no club subscription.</span></div>
        <div><Banknote size={26} /><strong>Shared growth</strong><span>Transparent transaction fees apply only when your club collects money or sells.</span></div>
        <div><Bot size={26} /><strong>Optional intelligence</strong><span>Premium AI saves time, creates opportunities and supports better decisions.</span></div>
      </section>
    </div>
  );
}

const pricingPlans = [
  { product: "Clubhouse Basic", user: "Clubs / Teams", price: "Free", note: "Core club website and community tools", action: "Start free", tone: "plain" },
  { product: "AI Coach Player", user: "Individual players", price: "R50/month", note: "Personal athlete AI and Career Agent", action: "Choose Player", tone: "wine" },
  { product: "AI Coach Pro", user: "Coaches", price: "R100/month", note: "Professional coaching AI and Career Agent", action: "Choose Pro", tone: "plain" },
  { product: "Club AI", user: "Clubs / Teams", price: "Paid subscription", note: "Advanced club operations and AI tools", action: "Talk to us", tone: "gold" },
  { product: "Store", user: "Clubs", price: "Transaction / service fee", note: "Products, tickets, memberships and donations", action: "Open Store", tone: "plain" },
];

const includedTools = ["Sponsor Finder", "AI Finance Coach", "Meeting AI"];

const freeFeatureGroups = [
  { title: "Your club home", items: ["Club website and public link", "Club logo, colours and profile", "Club news, media and documents", "Sponsor page and QR code"] },
  { title: "Your people", items: ["Unlimited basic teams", "Player, coach, parent and fan registration", "Team management and availability", "Club management structure"] },
  { title: "Your weekly rhythm", items: ["Fixtures and training schedules", "Basic attendance and events", "Team chat and club announcements", "Basic reports and meetings"] },
  { title: "Your club income", items: ["Basic online store", "Membership and event collection", "Donations and fundraising", "Transparent fee controls"] },
];

function Pricing({ showToast, navigate }: { showToast: (message: string) => void; navigate: (view: View) => void }) {
  const [feeChoice, setFeeChoice] = useState<"club" | "member">("club");
  const [showAllFreeFeatures, setShowAllFreeFeatures] = useState(false);
  const openPlan = (product: string) => {
    if (product === "AI Coach Player") navigate("player");
    else if (product === "AI Coach Pro") navigate("coach");
    else if (product === "Store") navigate("store");
    else if (product === "Club AI") showToast("Club AI subscription enquiry opened.");
    else showToast("Your Clubhouse Basic workspace is ready to start.");
  };

  return (
    <div className="page-stack pricing-page">
      <section className="pricing-hero">
        <div>
          <p className="eyebrow eyebrow-gold">Free for clubs. Built to help clubs grow.</p>
          <h1>Build your club&apos;s digital clubhouse for free.</h1>
          <p>No setup fee. No joining fee. No monthly club fee. Start with the tools your club needs, then choose optional services when they create more value.</p>
          <button className="button button-gold pricing-hero-button" onClick={() => openPlan("Clubhouse Basic")}>Create your clubhouse - FREE <ArrowRight size={17} /></button>
        </div>
        <div className="pricing-hero-motto"><span>“</span>The best gift<br />I can give is myself.<small>Where coaches create champions.</small></div>
      </section>

      <section className="free-value-section">
        <div className="free-value-heading"><p className="eyebrow">Clubhouse Basic - R0</p><h2>Useful from day one.<br />Free for as long as you need it.</h2><p>Essential club functions stay accessible. Premium options are there to save time, unlock growth and generate new opportunities, never to block the basics.</p><button className="text-button" onClick={() => setShowAllFreeFeatures((open) => !open)}>{showAllFreeFeatures ? "Show the essentials" : "See everything included"} <ChevronRight size={16} /></button></div>
        <div className={`free-feature-grid ${showAllFreeFeatures ? "free-feature-grid-open" : ""}`}>
          {freeFeatureGroups.map((group, groupIndex) => <article key={group.title} className={groupIndex > 1 && !showAllFreeFeatures ? "free-feature-extra" : ""}><span>0{groupIndex + 1}</span><h3>{group.title}</h3><ul>{group.items.map((item) => <li key={item}><Check size={15} />{item}</li>)}</ul></article>)}
        </div>
      </section>

      <section className="pricing-table" aria-label="Coach Player Clubhouse product pricing">
        <div className="pricing-table-head"><span>Product</span><span>Built for</span><span>Price</span><span>Get started</span></div>
        {pricingPlans.map((plan) => (
          <article key={plan.product} className={`pricing-row pricing-row-${plan.tone}`}>
            <div><h2>{plan.product}</h2><p>{plan.note}</p></div>
            <div className="pricing-user"><span className="pricing-label">Built for</span>{plan.user}</div>
            <div className="pricing-price"><span className="pricing-label">Price</span><strong>{plan.price}</strong></div>
            <button className={`button ${plan.tone === "wine" ? "button-gold" : "button-outline"}`} onClick={() => openPlan(plan.product)}>{plan.action} <ArrowRight size={16} /></button>
          </article>
        ))}
      </section>

      <section className="transaction-choice">
        <div><p className="eyebrow eyebrow-gold">Transparent transactions</p><h2>Your club keeps control of the fee.</h2><p>When a club collects membership, registration, tickets, donations, fundraising or store payments, a small platform and payment-processing fee can apply. The exact rate is configured by provider and country.</p><div className="fee-choice" role="group" aria-label="Choose transaction fee option"><button className={feeChoice === "club" ? "active" : ""} onClick={() => setFeeChoice("club")}>Option A<br /><strong>Club absorbs fee</strong></button><button className={feeChoice === "member" ? "active" : ""} onClick={() => setFeeChoice("member")}>Option B<br /><strong>Member pays fee</strong></button></div></div>
        <div className="fee-example"><p className="eyebrow">Illustrative R500 membership payment</p>{feeChoice === "club" ? <><div><span>Member pays</span><strong>R500.00</strong></div><div><span>Illustrative service fee</span><strong>- R14.50</strong></div><div className="fee-result"><span>Club receives</span><strong>R485.50</strong></div></> : <><div><span>Membership amount</span><strong>R500.00</strong></div><div><span>Illustrative service fee</span><strong>+ R14.50</strong></div><div className="fee-result"><span>Club receives</span><strong>R500.00</strong></div></>}<small>Example only. Show the final fee clearly before payment is confirmed.</small></div>
      </section>

      <section className="club-ai-included">
        <div><p className="eyebrow eyebrow-gold">Club AI - paid club package</p><h2>Your club&apos;s intelligent operations team.</h2><p>Bring funding, finances, sponsor outreach, meeting administration, documents and club planning into one human-approved workflow.</p><button className="button button-gold club-ai-button" onClick={() => showToast("Club AI subscription enquiry opened.")}>Ask about Club AI <ArrowRight size={16} /></button></div>
        <div className="included-tool-list">
          {includedTools.map((tool, index) => <div key={tool}><span>0{index + 1}</span><strong>{tool}</strong><Check size={19} /></div>)}
        </div>
      </section>

      <section className="career-ai-callout"><div><p className="eyebrow">A major AI pillar</p><h2>Career &amp; Development Agent</h2><p>Build a professional profile, create a development pathway, discover verified opportunities and prepare applications with the user in control.</p></div><div className="career-ai-pillars"><span>AI Coach Player</span><span>AI Coach Pro</span><span>Club AI</span><span className="active">Career &amp; Development Agent</span></div><button className="button button-outline" onClick={() => navigate("career")}>Open Career Agent <ArrowRight size={16} /></button></section>

      <section className="pricing-growth-callout"><div><p className="eyebrow">The shared-growth model</p><h2>When your club grows, Clubhouse grows with you.</h2></div><p>Members, payments, stores, fundraising, sponsors and optional AI services create value for your community first. See the complete flywheel and an example of how it works.</p><button className="button button-outline" onClick={() => navigate("growth")}>Explore the growth engine <ArrowRight size={16} /></button></section>

      <Disclaimer>Club AI is a paid club-level subscription. Pricing is configured for your club&apos;s size and requirements. AI outputs should be reviewed and approved by the appropriate club representative.</Disclaimer>
    </div>
  );
}

const growthSteps = [
  ["Club joins free", "Create the digital clubhouse with no setup, joining or monthly club fee."],
  ["Club builds its home", "Set up the website, teams, schedules, profiles and communication."],
  ["Members connect", "Players invite parents, supporters and the wider club community."],
  ["Club gets organised", "Attendance, events, registrations and team activity become easier to manage."],
  ["Club collects money", "Memberships, tickets, fundraising and donations can move through transparent checkout."],
  ["Club opens a store", "Merchandise and event products create a new, practical club income stream."],
  ["Club finds partners", "Sponsor tools create better research, proposals and follow-up opportunities."],
  ["People add AI", "Players, coaches and clubs choose premium AI tools when they create useful value."],
];

const revenueEngines = [
  {
    number: "01",
    title: "Payments & Commerce",
    strap: "When clubs transact, Clubhouse earns.",
    text: "Free clubs can collect membership, registration, tickets, fundraising, donations and store sales through one clear checkout.",
    bullets: ["Small transparent platform fee", "Club absorbs or member pays", "Store, tickets and fundraising included"],
    action: "Open commerce",
    view: "store" as View,
    icon: CreditCard,
  },
  {
    number: "02",
    title: "AI Subscriptions",
    strap: "High-margin tools for people who want more.",
    text: "Players, coaches and clubs opt into intelligence when it saves time, improves performance or unlocks better opportunities.",
    bullets: ["AI Coach Player - R50/month", "AI Coach Pro - R100/month", "Club AI for finance, sponsors and admin"],
    action: "Explore AI plans",
    view: "pricing" as View,
    icon: Bot,
  },
  {
    number: "03",
    title: "Sponsor Marketplace",
    strap: "Connect businesses with clubs that matter.",
    text: "Structured club opportunities and business preferences help create better community sponsorship matches.",
    bullets: ["AI matching by need, place and purpose", "Transparent success fee when a deal closes", "Sponsor visibility and relationship tools"],
    action: "Open marketplace",
    view: "sponsors" as View,
    icon: Gem,
  },
];

function Growth({ navigate, showToast }: { navigate: (view: View) => void; showToast: (message: string) => void }) {
  const [activeStep, setActiveStep] = useState(0);
  const [activeEngine, setActiveEngine] = useState(0);
  const [playerSubscribers, setPlayerSubscribers] = useState(50);
  const [coachSubscribers, setCoachSubscribers] = useState(20);
  const [transactionVolume, setTransactionVolume] = useState(100000);
  const [sponsorDeal, setSponsorDeal] = useState(100000);
  const aiPlayerRevenue = playerSubscribers * 50;
  const aiCoachRevenue = coachSubscribers * 100;
  const transactionRevenue = transactionVolume * 0.029;
  const sponsorMatchRevenue = sponsorDeal * 0.05;
  const recurringRevenue = aiPlayerRevenue + aiCoachRevenue + transactionRevenue;

  return (
    <div className="page-stack growth-page">
      <section className="growth-hero">
        <div><p className="eyebrow eyebrow-gold">Three major revenue engines</p><h1>Free for clubs. Built to create value with every transaction, subscription and match.</h1><p>Payments and commerce create practical day-to-day revenue. AI subscriptions create high-margin value. The sponsor marketplace creates high-trust community opportunity.</p><div className="growth-hero-actions"><button className="button button-gold" onClick={() => navigate("pricing")}>Start your club for free <ArrowRight size={17} /></button><button className="button button-ghost" onClick={() => navigate("sponsors")}>Find a sponsor</button></div></div>
        <div className="growth-quote"><span>3 ENGINES</span><strong>MORE CLUBS<br />MORE ACTIVITY<br />MORE VALUE</strong><small>Club, sponsor and platform succeed together.</small></div>
      </section>

      <section className="engine-section">
        <div className="engine-section-heading"><p className="eyebrow">The operating model</p><h2>Three engines. One free clubhouse.</h2><p>The free club experience attracts and serves the community. These engines earn only when a club or member receives additional value.</p></div>
        <div className="engine-grid">
          {revenueEngines.map((engine, index) => {
            const Icon = engine.icon;
            return <button key={engine.title} className={`engine-card ${activeEngine === index ? "active" : ""}`} onClick={() => setActiveEngine(index)}><span>{engine.number}</span><Icon size={25} /><h3>{engine.title}</h3><p>{engine.strap}</p></button>;
          })}
        </div>
        <motion.article key={activeEngine} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="engine-detail">
          <div><span>{revenueEngines[activeEngine].number}</span><h3>{revenueEngines[activeEngine].title}</h3><p>{revenueEngines[activeEngine].text}</p></div>
          <ul>{revenueEngines[activeEngine].bullets.map((bullet) => <li key={bullet}><Check size={16} />{bullet}</li>)}</ul>
          <button className="button button-gold" onClick={() => navigate(revenueEngines[activeEngine].view)}>{revenueEngines[activeEngine].action} <ArrowRight size={16} /></button>
        </motion.article>
      </section>

      <section className="flywheel-section">
        <div className="flywheel-heading"><p className="eyebrow">The growth flywheel</p><h2>A free start that builds momentum.</h2><p>Every step makes the club more connected, more capable and more able to create its own opportunities.</p></div>
        <div className="flywheel-layout">
          <div className="flywheel-steps">{growthSteps.map(([title], index) => <button key={title} className={activeStep === index ? "active" : ""} onClick={() => setActiveStep(index)}><span>{String(index + 1).padStart(2, "0")}</span>{title}</button>)}</div>
          <motion.article key={activeStep} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="flywheel-detail"><span>STEP {String(activeStep + 1).padStart(2, "0")}</span><h3>{growthSteps[activeStep][0]}</h3><p>{growthSteps[activeStep][1]}</p><div className="flywheel-detail-bottom"><Users size={21} /><strong>{activeStep < 4 ? "Grow the community first." : "Create value, then share in the upside."}</strong></div></motion.article>
        </div>
      </section>

      <section className="revenue-lab">
        <div className="revenue-lab-intro"><p className="eyebrow eyebrow-gold">Illustrative revenue model</p><h2>One club. Many ways to create value.</h2><p>Adjust the inputs to see how optional subscriptions and activity-based fees can support the platform while the club stays free.</p><Disclaimer>Illustration only, not a quote or forecast. Transaction, payment processing and sponsor-matching fees are configurable and must be disclosed to all parties.</Disclaimer></div>
        <div className="revenue-controls">
          <label><span>Players using AI Coach Player</span><strong>{playerSubscribers}</strong><input type="range" min="0" max="200" step="5" value={playerSubscribers} onChange={(event) => setPlayerSubscribers(Number(event.target.value))} /><small>{money.format(playerSubscribers * 50)} / month at R50 each</small></label>
          <label><span>Coaches using AI Coach Pro</span><strong>{coachSubscribers}</strong><input type="range" min="0" max="60" step="1" value={coachSubscribers} onChange={(event) => setCoachSubscribers(Number(event.target.value))} /><small>{money.format(coachSubscribers * 100)} / month at R100 each</small></label>
          <label><span>Monthly club payment volume</span><strong>{money.format(transactionVolume)}</strong><input type="range" min="0" max="250000" step="5000" value={transactionVolume} onChange={(event) => setTransactionVolume(Number(event.target.value))} /><small>{money.format(transactionRevenue)} / month at illustrative 2.9%</small></label>
          <label><span>Facilitated sponsorship deal</span><strong>{money.format(sponsorDeal)}</strong><input type="range" min="0" max="250000" step="5000" value={sponsorDeal} onChange={(event) => setSponsorDeal(Number(event.target.value))} /><small>{money.format(sponsorMatchRevenue)} optional one-off matching fee at 5%</small></label>
        </div>
        <aside className="revenue-total"><p>Potential recurring value</p><strong>{money.format(recurringRevenue)}<small>/ month</small></strong><span>From optional AI subscriptions and illustrated transaction service fees.</span><div><span>Optional sponsor matching fee</span><b>{money.format(sponsorMatchRevenue)}</b></div><button className="button button-gold" onClick={() => showToast("Your model has been saved as a draft scenario.")}>Save this scenario <FileCheck2 size={16} /></button></aside>
      </section>

      <section className="marketplace-section">
        <div><p className="eyebrow">Long-term ecosystem</p><h2>More useful ways for a sports community to thrive.</h2></div>
        <div className="marketplace-grid"><article><ShoppingBag size={24} /><h3>Club marketplace</h3><p>Merchandise, equipment, print-on-demand and supplier referrals that reduce club admin.</p></article><article><Users size={24} /><h3>Coach marketplace</h3><p>Personal coaching, clinics, fitness, skills and video analysis with transparent commission.</p></article><article><FileText size={24} /><h3>Coach Player Academy</h3><p>Courses for coaches, club administrators and player development, created by experts.</p></article><article><ShieldCheck size={24} /><h3>Privacy-first analytics</h3><p>Private club insights for attendance, retention, store performance and sponsor exposure.</p></article></div>
      </section>
    </div>
  );
}

function Finance({ showToast }: { showToast: (message: string) => void }) {
  const [question, setQuestion] = useState("");
  const [response, setResponse] = useState<string | null>(null);
  const askFinance = (event: FormEvent) => {
    event.preventDefault();
    if (!question.trim()) return;
    setResponse("Based on this workspace snapshot, R12,600 is currently outstanding. Start with a friendly membership reminder, then review the 7 invoices that are more than 30 days old. I can prepare the message and a follow-up list for your approval.");
    setQuestion("");
  };

  return (
    <div className="page-stack">
      <PageHeading eyebrow="Club AI / finance" title="AI Finance Coach">
        <button className="button button-wine" onClick={() => showToast("A draft monthly finance report is ready for review.")}>Create monthly report <FileText size={17} /></button>
      </PageHeading>
      <p className="page-intro">Simple, plain-language financial support for the people keeping a club running. Track money, prepare paperwork and decide what to do next.</p>

      <section className="metrics-grid finance-metrics">
        <Metric label="Income this month" value={money.format(42600)} detail="Memberships, store and donations" tone="gold" />
        <Metric label="Expenses this month" value={money.format(27350)} detail="Transport, kit and facilities" />
        <Metric label="Projected month end" value={money.format(63400)} detail="Based on confirmed income" tone="wine" />
        <Metric label="Unpaid invoices" value="18" detail={`${money.format(12600)} still to collect`} />
      </section>

      <section className="content-grid finance-layout">
        <div className="surface ai-console">
          <div className="surface-heading">
            <div><p className="eyebrow">Your assistant</p><h2>Ask AI Finance Coach</h2></div>
            <span className="live-dot">Finance-aware demo</span>
          </div>
          <div className="ai-message ai-message-bot"><Bot size={19} /><p>I can help turn your club numbers into a clear next step. Ask about cash flow, budgets, outstanding fees, fundraising or a report.</p></div>
          <div className="prompt-chips">
            <button onClick={() => setQuestion("What should I follow up this week?")}>What should I follow up?</button>
            <button onClick={() => setQuestion("Summarise our cash flow")}>Summarise cash flow</button>
            <button onClick={() => setQuestion("Prepare membership reminders")}>Prepare reminders</button>
          </div>
          <AnimatePresence>
            {response && <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="ai-response"><p>{response}</p><div><VerifiedTag>Used club workspace data</VerifiedTag><span>Human approval required before sending</span></div></motion.div>}
          </AnimatePresence>
          <form className="assistant-form" onSubmit={askFinance}>
            <input value={question} onChange={(event) => setQuestion(event.target.value)} placeholder="Ask about your club finances..." aria-label="Ask AI Finance Coach" />
            <button type="submit" aria-label="Send question"><Send size={18} /></button>
          </form>
          <Disclaimer>AI explanations are support, not professional accounting, tax or legal advice. Review reports with an authorised professional where needed.</Disclaimer>
        </div>

        <aside className="surface cashflow-card">
          <div className="surface-heading"><div><p className="eyebrow">Cash flow</p><h2>Money in, money out</h2></div><Banknote size={22} /></div>
          <div className="cash-chart" aria-label="Cash flow visualisation">
            {[62, 42, 71, 48, 86, 67, 78].map((height, index) => <span key={index} style={{ height: `${height}%` }} />)}
          </div>
          <div className="chart-labels"><span>01</span><span>07</span><span>14</span><span>21</span><span>28</span></div>
          <div className="ledger-summary"><span><i className="dot dot-gold" />Income <strong>{money.format(42600)}</strong></span><span><i className="dot dot-wine" />Expenses <strong>{money.format(27350)}</strong></span></div>
        </aside>
      </section>

      <section className="surface ledger-panel">
        <div className="surface-heading"><div><p className="eyebrow">Recent activity</p><h2>Finance ledger</h2></div><button className="text-button" onClick={() => showToast("Ledger export queued as CSV.")}>Export CSV <ArrowRight size={16} /></button></div>
        <div className="table-wrap"><table><thead><tr><th>Date</th><th>Description</th><th>Category</th><th>Status</th><th>Amount</th></tr></thead><tbody>
          <tr><td>24 Jun</td><td>U15 membership payments</td><td>Membership</td><td><span className="status status-success">Received</span></td><td className="amount-positive">+ {money.format(5800)}</td></tr>
          <tr><td>23 Jun</td><td>First Aid kit order</td><td>Equipment</td><td><span className="status">Paid</span></td><td>- {money.format(1450)}</td></tr>
          <tr><td>21 Jun</td><td>Spring tour deposit</td><td>Events</td><td><span className="status status-warning">Due 28 Jun</span></td><td>- {money.format(7200)}</td></tr>
          <tr><td>20 Jun</td><td>Store order #1024</td><td>Store</td><td><span className="status status-success">Received</span></td><td className="amount-positive">+ {money.format(960)}</td></tr>
        </tbody></table></div>
      </section>
    </div>
  );
}

function Sponsors({ showToast }: { showToast: (message: string) => void }) {
  const [brief, setBrief] = useState("We are an U18 rugby club in Pretoria looking for a sponsor for equipment and transport.");
  const [researchState, setResearchState] = useState<"idle" | "researching" | "complete">("idle");
  const [marketplaceSide, setMarketplaceSide] = useState<"club" | "business">("club");
  const [marketplaceConnected, setMarketplaceConnected] = useState(false);
  const startResearch = (event: FormEvent) => {
    event.preventDefault();
    if (!brief.trim()) return;
    setResearchState("researching");
    window.setTimeout(() => setResearchState("complete"), 850);
  };

  return (
    <div className="page-stack">
      <PageHeading eyebrow="Club AI / partnerships" title="Find a sponsor with AI">
        <button className="button button-wine" onClick={() => showToast("Sponsor package builder opened.")}>Build package <Gem size={17} /></button>
      </PageHeading>
      <p className="page-intro">Brief the AI about your club and it will structure a transparent research plan, shortlist criteria and outreach materials. Verify every company and contact before approaching them.</p>

      <section className="marketplace-match surface">
        <div className="marketplace-copy"><p className="eyebrow">Coach Player Sponsor Marketplace</p><h2>Match sport with meaningful local support.</h2><p>Clubs publish clear opportunities. Businesses share the communities and causes they want to support. AI helps identify the strongest fit before either side chooses to connect.</p><div className="marketplace-switch" role="group" aria-label="Sponsor marketplace side"><button className={marketplaceSide === "club" ? "active" : ""} onClick={() => setMarketplaceSide("club")}>We need sponsorship</button><button className={marketplaceSide === "business" ? "active" : ""} onClick={() => setMarketplaceSide("business")}>We want to sponsor sport</button></div></div>
        <div className="marketplace-profile"><p className="eyebrow">{marketplaceSide === "club" ? "Club opportunity" : "Business preference"}</p>{marketplaceSide === "club" ? <><h3>U18 Rugby Development Programme</h3><dl><div><dt>Location</dt><dd>Pretoria</dd></div><div><dt>Support needed</dt><dd>R50,000</dd></div><div><dt>Purpose</dt><dd>Transport and equipment</dd></div><div><dt>Community reach</dt><dd>35 youth players</dd></div></dl></> : <><h3>Community Sport Partner</h3><dl><div><dt>Location</dt><dd>Gauteng</dd></div><div><dt>Budget</dt><dd>R100,000</dd></div><div><dt>Interest</dt><dd>Youth rugby</dd></div><div><dt>Focus</dt><dd>Community development</dd></div></dl></>}</div>
        <div className="match-score"><p>Illustrative AI match</p><strong>92<small>%</small></strong><span>Strong local, youth-development and budget alignment.</span><button className="button button-gold" onClick={() => { setMarketplaceConnected(true); showToast("Connection request saved for both parties to review."); }}>{marketplaceConnected ? "Connection requested" : "Connect sponsor to club"} <ArrowRight size={16} /></button></div>
        <div className="marketplace-note"><ShieldCheck size={16} />This is a marketplace example, not a verified company or sponsorship commitment. Both parties must review, agree and disclose any matching fee before a deal is completed.</div>
      </section>

      <section className="sponsor-search surface">
        <div><p className="eyebrow">Sponsor search brief</p><h2>Start with your real need.</h2></div>
        <form onSubmit={startResearch}>
          <textarea value={brief} onChange={(event) => setBrief(event.target.value)} rows={3} aria-label="Sponsor search brief" />
          <div className="form-footer"><span>Prioritises location, relevance, community involvement and public sponsorship information.</span><button className="button button-gold" type="submit" disabled={researchState === "researching"}>{researchState === "researching" ? "Preparing research..." : <>Research opportunities <Search size={17} /></>}</button></div>
        </form>
      </section>

      <AnimatePresence mode="wait">
        {researchState === "complete" && (
          <motion.section initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} className="sponsor-report">
            <div className="report-heading"><div><p className="eyebrow">Research report</p><h2>U18 rugby / Pretoria</h2></div><VerifiedTag>External research not yet connected</VerifiedTag></div>
            <div className="transparency-grid">
              <div className="transparency-card verified-card"><ShieldCheck size={21} /><div><strong>Verified information</strong><p>No live web search has been run in this prototype. Company names, contacts, sponsorship programmes and financial details must be sourced from public records before use.</p></div></div>
              <div className="transparency-card recommendation-card"><Sparkles size={21} /><div><strong>AI recommendations</strong><p>Prioritise businesses near your training ground with youth, community or transport alignment. Use the brief below as a research and outreach checklist.</p></div></div>
            </div>
            <div className="opportunity-grid">
              <article>
                <span className="opportunity-number">01</span><p className="eyebrow">Equipment partner</p><h3>Sports retail and local gym partners</h3><p>Relevant for kit, balls, recovery equipment and youth-development support.</p><ul><li><Check size={15} />Search within Pretoria first</li><li><Check size={15} />Review public community initiatives</li><li><Check size={15} />Offer a R25,000 equipment package</li></ul><button onClick={() => showToast("Equipment sponsor proposal selected.")} className="text-button">Create proposal <ArrowRight size={16} /></button>
              </article>
              <article>
                <span className="opportunity-number">02</span><p className="eyebrow">Transport partner</p><h3>Vehicle, logistics and taxi businesses</h3><p>Relevant for away fixtures, tournament travel and player access.</p><ul><li><Check size={15} />Map routes and usage</li><li><Check size={15} />Check CSI or community pages</li><li><Check size={15} />Offer transport visibility benefits</li></ul><button onClick={() => showToast("Transport sponsor proposal selected.")} className="text-button">Create proposal <ArrowRight size={16} /></button>
              </article>
              <article>
                <span className="opportunity-number">03</span><p className="eyebrow">Community partner</p><h3>Medical, food and professional services</h3><p>Good fit for match-day support, player wellbeing, meals or local events.</p><ul><li><Check size={15} />Look for local decision makers</li><li><Check size={15} />Confirm public contact channels</li><li><Check size={15} />Start with a meeting request</li></ul><button onClick={() => showToast("Community sponsor proposal selected.")} className="text-button">Create proposal <ArrowRight size={16} /></button>
              </article>
            </div>
            <Disclaimer>Suggested opportunities are AI-generated recommendations based on the search brief. Treat all company, contact and sponsorship information as unverified until supported by public sources.</Disclaimer>
          </motion.section>
        )}
      </AnimatePresence>

      <section className="surface crm-panel">
        <div className="surface-heading"><div><p className="eyebrow">Sponsor outreach CRM</p><h2>Keep every follow-up moving</h2></div><button className="button button-outline" onClick={() => showToast("New sponsor record added to research queue.")}><Plus size={16} /> Add opportunity</button></div>
        <div className="pipeline">
          <div><span className="pipeline-label">Researching</span><article className="pipeline-item"><strong>Equipment partner search</strong><small>Research brief complete</small><em>Today</em></article></div>
          <div><span className="pipeline-label">Contacted</span><article className="pipeline-item"><strong>Local logistics prospect</strong><small>Introduction draft awaiting approval</small><em>Follow up Fri</em></article></div>
          <div><span className="pipeline-label">Proposal sent</span><article className="pipeline-item"><strong>Community partnership</strong><small>R25,000 kit proposal</small><em>7 days ago</em></article></div>
          <div><span className="pipeline-label">Active sponsor</span><article className="pipeline-item pipeline-item-active"><strong>Match-day partner</strong><small>Contract review in September</small><em>Active</em></article></div>
        </div>
      </section>
    </div>
  );
}

function Documents({ showToast }: { showToast: (message: string) => void }) {
  const documentTypes = ["Sponsorship proposal", "Sponsorship letter", "Club profile", "Funding request", "Event proposal", "Meeting minutes", "Coach agreement", "Thank-you letter"];
  const [documentType, setDocumentType] = useState(documentTypes[0]);
  const [created, setCreated] = useState(false);
  const generate = () => { setCreated(true); showToast(`${documentType} draft prepared for review.`); };

  return (
    <div className="page-stack">
      <PageHeading eyebrow="Club AI / paperwork" title="Club Document AI"><span className="approval-note"><FileCheck2 size={16} /> Always review before publishing</span></PageHeading>
      <p className="page-intro">Create the club paperwork that keeps good ideas moving. Start with a clear draft, then edit, approve and export it your way.</p>
      <section className="document-workspace">
        <aside className="surface document-picker">
          <p className="eyebrow">Create a document</p><h2>What does your club need?</h2>
          <div className="document-list">
            {documentTypes.map((item) => <button key={item} className={documentType === item ? "selected" : ""} onClick={() => { setDocumentType(item); setCreated(false); }}><FileText size={17} />{item}<ChevronRight size={16} /></button>)}
          </div>
        </aside>
        <div className="surface document-editor">
          <div className="surface-heading"><div><p className="eyebrow">AI draft builder</p><h2>{documentType}</h2></div><button className="button button-wine" onClick={generate}><Sparkles size={16} /> Generate draft</button></div>
          <div className="document-prompts"><label>Club or project name<input defaultValue="Riverside Rugby Club U18 Development Programme" /></label><label>Purpose<textarea defaultValue="Request support for player equipment, transport and accessible youth rugby opportunities." rows={3} /></label></div>
          {created ? <motion.article initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="document-preview"><div><span>DRAFT</span><VerifiedTag>AI-generated content</VerifiedTag></div><h3>{documentType}</h3><p>Riverside Rugby Club is seeking a community-minded partner to support our U18 development programme. Your contribution will help remove practical barriers so young players can train, travel and represent their club with pride.</p><p>This draft includes a club overview, the requested support, proposed sponsor benefits and a clear next step. Add verified club details, accurate budgets and named contacts before publishing.</p><footer><button onClick={() => showToast("PDF download is prepared.")}><ReceiptText size={16} /> PDF</button><button onClick={() => showToast("Word export is prepared.")}><FileText size={16} /> Word</button><button onClick={() => showToast("Shareable review link copied.")}><Copy size={16} /> Share</button></footer></motion.article> : <div className="document-empty"><FileText size={34} /><p>Choose a document and generate an editable first draft.</p><small>AI will show what needs club approval before you send it.</small></div>}
          <Disclaimer>Template content is not legal, financial or regulatory advice. Confirm local requirements and obtain professional advice where appropriate.</Disclaimer>
        </div>
      </section>
    </div>
  );
}

function Meetings({ showToast }: { showToast: (message: string) => void }) {
  const [meetingTitle, setMeetingTitle] = useState("Monthly committee meeting");
  const [meetingKind, setMeetingKind] = useState("Committee meeting");
  const [joinRule, setJoinRule] = useState("Guests need approval");
  const [meetingLink, setMeetingLink] = useState<string | null>(null);
  const [minutesGenerated, setMinutesGenerated] = useState(false);

  const createMeeting = (event: FormEvent) => {
    event.preventDefault();
    setMeetingLink(`coachplayerclubhouse.com/meeting/${Math.random().toString(36).slice(2, 8).toUpperCase()}`);
  };

  return (
    <div className="page-stack">
      <PageHeading eyebrow="Club secretary system" title="Club meetings"><button className="button button-wine" onClick={() => showToast("Meeting records open for committee review.")}>View past minutes <FileText size={17} /></button></PageHeading>
      <p className="page-intro">Create secure club meetings, organise the agenda and turn discussion into accountable action. The secretary remains in control at every step.</p>
      <section className="meeting-grid">
        <form className="surface meeting-creator" onSubmit={createMeeting}>
          <div className="surface-heading"><div><p className="eyebrow">New virtual meeting</p><h2>Create and invite</h2></div><Video size={23} /></div>
          <label>Meeting title<input value={meetingTitle} onChange={(event) => setMeetingTitle(event.target.value)} /></label>
          <div className="form-row"><label>Meeting type<select value={meetingKind} onChange={(event) => setMeetingKind(event.target.value)}><option>Committee meeting</option><option>Coach meeting</option><option>Parent meeting</option><option>AGM meeting</option><option>Sponsor meeting</option></select></label><label>Guest access<select value={joinRule} onChange={(event) => setJoinRule(event.target.value)}><option>Guests need approval</option><option>Guests join directly</option><option>Password required</option><option>Members only</option></select></label></div>
          <div className="form-row"><label>Date<input type="date" defaultValue="2025-07-03" /></label><label>Time<input type="time" defaultValue="18:30" /></label></div>
          <button className="button button-gold full-button" type="submit">Create meeting link <ArrowRight size={17} /></button>
          <AnimatePresence>{meetingLink && <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="meeting-link"><strong>Your unique invitation link</strong><span>{meetingLink}</span><button type="button" onClick={() => showToast("Meeting invitation link copied.")}><Copy size={16} /> Copy link</button></motion.div>}</AnimatePresence>
        </form>

        <div className="surface agenda-panel">
          <div className="surface-heading"><div><p className="eyebrow">Meeting agenda builder</p><h2>{meetingTitle || "Your meeting agenda"}</h2></div><button className="text-button" onClick={() => showToast("AI added items from the previous approved meeting.")}>Use previous <Sparkles size={15} /></button></div>
          <div className="agenda-meta"><span><CalendarDays size={15} /> 03 July 2025</span><span><Clock3 size={15} /> 18:30</span><span><Users size={15} /> {meetingKind}</span></div>
          <ol className="agenda-list"><li>Opening and attendance</li><li>Apologies</li><li>Previous minutes and matters arising</li><li>Financial report</li><li>Team and coaching reports</li><li>Sponsorship and fundraising</li><li>Events and general</li><li>Closing</li></ol>
          <div className="agenda-footer"><span><LockKeyhole size={14} /> {joinRule}</span><button className="button button-outline" onClick={() => showToast("Agenda shared with selected club members.")}>Share agenda</button></div>
        </div>
      </section>

      <section className="surface minutes-panel">
        <div className="surface-heading"><div><p className="eyebrow">AI meeting assistant</p><h2>Review the meeting, then publish</h2></div><button className="button button-outline" onClick={() => setMinutesGenerated(true)}><Bot size={16} /> Draft minutes</button></div>
        {minutesGenerated ? <div className="minutes-draft"><div><VerifiedTag>Generated from meeting notes</VerifiedTag><span>Needs secretary approval</span></div><h3>Draft action items</h3><ul><li><Check size={16} />Treasurer to share the June finance report by Friday.</li><li><Check size={16} />Sponsorship lead to send the equipment proposal after committee review.</li><li><Check size={16} />Director of Rugby to confirm tournament transport options.</li></ul><button className="button button-wine" onClick={() => showToast("Minutes submitted for secretary approval.")}>Submit for approval <FileCheck2 size={16} /></button></div> : <div className="minutes-empty"><Bot size={30} /><p>After your meeting, AI can organise notes into decisions, owners, deadlines and draft minutes.</p></div>}
      </section>
    </div>
  );
}

const storeProducts = [
  { id: 1, name: "Club jersey", price: 450, stock: "18 left", badge: "Best seller", shade: "jersey" },
  { id: 2, name: "Training tee", price: 220, stock: "42 left", badge: "New", shade: "tee" },
  { id: 3, name: "Club cap", price: 160, stock: "26 left", badge: "", shade: "cap" },
  { id: 4, name: "Match-day tickets", price: 50, stock: "Open sale", badge: "Event", shade: "ticket" },
];

function Store({ showToast }: { showToast: (message: string) => void }) {
  const [cart, setCart] = useState<number[]>([]);
  const [feePayer, setFeePayer] = useState<"club" | "member">("club");
  const total = useMemo(() => cart.reduce((sum, id) => sum + (storeProducts.find((product) => product.id === id)?.price ?? 0), 0), [cart]);
  const serviceFee = total * 0.029;
  const checkoutTotal = feePayer === "member" ? total + serviceFee : total;
  const clubReceives = feePayer === "club" ? total - serviceFee : total;
  return (
    <div className="page-stack">
      <PageHeading eyebrow="Payments and commerce" title="Sell, collect and support the club."><button className="button button-wine" onClick={() => showToast("Product creation panel opened.")}><Plus size={17} /> Add product</button></PageHeading>
      <p className="page-intro">Every club gets a free store and a checkout that can collect membership, registration, tickets, donations, fundraising and merchandise payments. Payment providers stay configurable by country.</p>
      <section className="commerce-engine surface"><div><p className="eyebrow">Revenue engine 01</p><h2>Payments that work around your community.</h2><p>Coach Player Clubhouse earns a small transparent platform fee when the club creates a successful transaction. Your club chooses who carries that fee.</p></div><div className="commerce-categories"><span>Membership</span><span>Registration</span><span>Store</span><span>Tickets</span><span>Fundraising</span><span>Donations</span><span>Camps</span><span>Clinics</span></div><div className="commerce-fee-choice"><button className={feePayer === "club" ? "active" : ""} onClick={() => setFeePayer("club")}>Club absorbs fee</button><button className={feePayer === "member" ? "active" : ""} onClick={() => setFeePayer("member")}>Member pays fee</button></div></section>
      <section className="store-metrics"><Metric label="Sales this month" value={money.format(8650)} detail="62 paid orders" tone="wine" /><Metric label="Best seller" value="Club jersey" detail="24 sold this month" tone="gold" /><Metric label="Low stock" value="01" detail="Home jersey - 18 remaining" /></section>
      <section className="store-layout">
        <div className="product-grid">
          {storeProducts.map((product) => <article key={product.id} className="product-card"><div className={`product-image product-${product.shade}`}><ShoppingBag size={38} /><span>{product.badge}</span></div><div><small>{product.stock}</small><h2>{product.name}</h2><strong>{money.format(product.price)}</strong></div><button className="button button-outline" onClick={() => { setCart((items) => [...items, product.id]); showToast(`${product.name} added to cart.`); }}>Add to cart <Plus size={16} /></button></article>)}
        </div>
        <aside className="surface cart-panel"><div className="surface-heading"><div><p className="eyebrow">Club cart</p><h2>{cart.length} item{cart.length === 1 ? "" : "s"}</h2></div><ShoppingBag size={21} /></div>{cart.length ? <><div className="cart-lines">{cart.map((id, index) => { const product = storeProducts.find((item) => item.id === id); return product ? <div key={`${id}-${index}`}><span>{product.name}</span><strong>{money.format(product.price)}</strong><button aria-label={`Remove ${product.name}`} onClick={() => setCart((items) => items.filter((_, itemIndex) => itemIndex !== index))}><X size={14} /></button></div> : null; })}</div><div className="checkout-breakdown"><span>Order amount <b>{money.format(total)}</b></span><span>Illustrative service fee {feePayer === "member" ? <b>+ {money.format(serviceFee)}</b> : <b>- {money.format(serviceFee)}</b>}</span><span>Club receives <b>{money.format(clubReceives)}</b></span></div><div className="cart-total"><span>{feePayer === "member" ? "Member pays" : "Checkout total"}</span><strong>{money.format(checkoutTotal)}</strong></div><button className="button button-gold full-button" onClick={() => showToast("Checkout is ready. Connect a country-specific payment provider to accept live payments.")}>Go to checkout <CreditCard size={17} /></button></> : <div className="cart-empty"><Package size={28} /><p>Your cart is ready for products, tickets, donations and membership payments.</p></div>}<Disclaimer>Fee is illustrative. Show the final platform and provider fees clearly before payment confirmation.</Disclaimer></aside>
      </section>
    </div>
  );
}

function Player({ showToast }: { showToast: (message: string) => void }) {
  const [sessionLength, setSessionLength] = useState<30 | 60>(30);
  const [prompt, setPrompt] = useState("");
  const [coachAnswer, setCoachAnswer] = useState<string | null>(null);
  const askCoach = (event: FormEvent) => {
    event.preventDefault();
    if (!prompt.trim()) return;
    setCoachAnswer(`Here is a focused ${sessionLength}-minute rugby wing session: acceleration mechanics, two speed sets, a finishing drill and a short recovery block. Adjust intensity if you feel pain, fatigue or need advice from a qualified coach or medical professional.`);
    setPrompt("");
  };
  return (
    <div className="page-stack">
      <PageHeading eyebrow="Premium athlete plan / R50 per month" title="AI Coach Player"><span className="plan-badge"><ZapIcon /> Personal athlete assistant</span></PageHeading>
      <p className="page-intro">A flexible, sport-aware training companion for your goals, time and available equipment. It supports your coach, never replaces qualified advice.</p>
      <section className="player-top-grid">
        <div className="surface player-profile"><div className="profile-avatar">TM</div><div><p className="eyebrow">Your player profile</p><h2>Thabo Mokoena</h2><p>Rugby · Wing · Age 17 · Intermediate</p></div><button className="text-button" onClick={() => showToast("Player profile settings opened.")}>Edit profile <Settings size={15} /></button></div>
        <div className="surface player-goals"><p className="eyebrow">My goals</p><div className="goal-list"><span>Speed <i><b style={{ width: "72%" }} /></i><em>72%</em></span><span>Fitness <i><b style={{ width: "61%" }} /></i><em>61%</em></span><span>Finishing <i><b style={{ width: "54%" }} /></i><em>54%</em></span></div></div>
      </section>
      <section className="content-grid player-layout">
        <div className="surface session-card"><div className="surface-heading"><div><p className="eyebrow">Today&apos;s training</p><h2>Speed and finishing</h2></div><div className="session-toggle"><button className={sessionLength === 30 ? "active" : ""} onClick={() => setSessionLength(30)}>30 min</button><button className={sessionLength === 60 ? "active" : ""} onClick={() => setSessionLength(60)}>60 min</button></div></div><p className="session-description">A rugby-wing session built around acceleration, field awareness and calm finishing.</p><div className="session-timeline"><span><b>05</b>Dynamic warm-up</span><span><b>{sessionLength === 30 ? "10" : "20"}</b>Acceleration mechanics</span><span><b>{sessionLength === 30 ? "10" : "25"}</b>Finishing and decision drill</span><span><b>05</b>Recovery and reflection</span></div><button className="button button-wine" onClick={() => showToast("Today's session marked as started.")}>Start session <ArrowRight size={17} /></button></div>
        <div className="surface player-chat"><div className="surface-heading"><div><p className="eyebrow">My AI coach</p><h2>Ask about your next step</h2></div><Bot size={22} /></div><p>Try: “I only have 30 minutes today” or “How do I improve my acceleration?”</p>{coachAnswer && <div className="coach-answer"><Bot size={17} /><span>{coachAnswer}</span></div>}<form className="assistant-form" onSubmit={askCoach}><input value={prompt} onChange={(event) => setPrompt(event.target.value)} placeholder="Ask your AI Coach Player..." /><button type="submit" aria-label="Ask coach"><Send size={18} /></button></form><Disclaimer>Training guidance is educational and not medical advice. Work with qualified professionals for injuries, health and contact-sport safety.</Disclaimer></div>
      </section>
      <section className="surface multi-sport"><div><p className="eyebrow">Multi-sport ready</p><h2>Built around the sport you play.</h2></div><div>{["Rugby", "Football", "Netball", "Basketball", "Athletics", "Hockey", "Cricket", "Tennis"].map((sport) => <span key={sport}>{sport}</span>)}</div></section>
    </div>
  );
}

function ZapIcon() { return <Activity size={15} />; }

function Coach({ showToast }: { showToast: (message: string) => void }) {
  const [sessionBuilt, setSessionBuilt] = useState(false);
  return (
    <div className="page-stack">
      <PageHeading eyebrow="Premium coach plan / R100 per month" title="AI Coach Pro"><span className="plan-badge"><Target size={15} /> Coaching workspace</span></PageHeading>
      <p className="page-intro">Plan better sessions, develop players and keep the detail that helps a team improve. Adapt every draft to your players, facility and safety requirements.</p>
      <section className="coach-builder surface">
        <div className="surface-heading"><div><p className="eyebrow">Coach AI session builder</p><h2>Build your next session</h2></div><button className="button button-wine" onClick={() => { setSessionBuilt(true); showToast("Defence session generated for coach review."); }}><Sparkles size={16} /> Generate session</button></div>
        <div className="builder-fields"><label>Sport<select defaultValue="Rugby"><option>Rugby</option><option>Football</option><option>Netball</option><option>Hockey</option></select></label><label>Age group<select defaultValue="U15"><option>U13</option><option>U15</option><option>U18</option><option>Senior</option></select></label><label>Focus<select defaultValue="Defence"><option>Defence</option><option>Attack</option><option>Skills</option><option>Fitness</option></select></label><label>Duration<select defaultValue="90 minutes"><option>60 minutes</option><option>90 minutes</option><option>120 minutes</option></select></label><label>Players<input defaultValue="25" /></label><label>Equipment<textarea defaultValue="Cones, balls, tackle shields, bibs" rows={1} /></label></div>
        {sessionBuilt ? <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="built-session"><div><VerifiedTag>AI draft session</VerifiedTag><span>Coach approval required</span></div><h3>U15 Rugby - Defence / 90 minutes</h3><div className="session-steps"><span><b>10m</b>Warm-up and movement prep</span><span><b>10m</b>Activation and tracking lines</span><span><b>15m</b>Defensive shape walkthrough</span><span><b>15m</b>Tackling progression</span><span><b>20m</b>Semi-opposed defence drill</span><span><b>15m</b>Conditioned game</span><span><b>05m</b>Cool-down and review</span></div><div className="coaching-note"><ClipboardCheck size={17} /><p><strong>Safety note:</strong> Check player readiness, contact experience and surface conditions before progressing to live tackle activity.</p></div></motion.div> : <div className="builder-empty"><Target size={30} /><p>Set the session details and generate a structured, editable coaching draft.</p></div>}
      </section>
      <section className="content-grid coach-bottom-grid"><div className="surface"><div className="surface-heading"><div><p className="eyebrow">Player development</p><h2>Turn observations into action</h2></div><Users size={21} /></div><p className="soft-copy">“Player struggles to maintain defensive alignment.”</p><div className="development-list"><span><Check size={16} />Development goal: maintain line connection</span><span><Check size={16} />Weekly target: scan, call and fold on every phase</span><span><Check size={16} />Assessment: review two clips at the next match</span></div><button className="text-button" onClick={() => showToast("Player development plan created.")}>Create development plan <ArrowRight size={16} /></button></div><div className="surface"><div className="surface-heading"><div><p className="eyebrow">Season support</p><h2>Keep the bigger picture</h2></div><CalendarDays size={21} /></div><div className="season-list"><span><b>08</b><div><strong>Sessions this month</strong><small>5 skills, 2 fitness, 1 match prep</small></div></span><span><b>92%</b><div><strong>Team attendance</strong><small>Up 4% from last month</small></div></span><span><b>04</b><div><strong>Player reviews due</strong><small>AI can draft a review framework</small></div></span></div></div></section>
    </div>
  );
}

type CareerRole = "player" | "coach";
type CareerTab = "dashboard" | "profile" | "development" | "opportunities" | "applications" | "portfolio" | "chat" | "privacy";
type CareerOpportunity = [string, string, string, number, string];
type CareerData = {
  greeting: string;
  journey: string;
  profile: number;
  development: number;
  readiness: number;
  identity: string;
  premium: string;
  priority: string;
  action: string;
  goal: string;
  profileItems: [string, string, string][];
  opportunities: CareerOpportunity[];
};

const careerTabs: { id: CareerTab; label: string; icon: LucideIcon }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "profile", label: "My profile", icon: UserRound },
  { id: "development", label: "My development", icon: GraduationCap },
  { id: "opportunities", label: "My opportunities", icon: Search },
  { id: "applications", label: "My applications", icon: FileCheck2 },
  { id: "portfolio", label: "My portfolio", icon: Award },
  { id: "chat", label: "AI career chat", icon: Bot },
  { id: "privacy", label: "Privacy and discoverability", icon: ShieldCheck },
];

function CareerAgent({ showToast, navigate }: { showToast: (message: string) => void; navigate: (view: View) => void }) {
  const [role, setRole] = useState<CareerRole>("player");
  const [tab, setTab] = useState<CareerTab>("dashboard");
  const [profileBoost, setProfileBoost] = useState(0);
  const [discoverable, setDiscoverable] = useState(false);
  const [visibility, setVisibility] = useState("Private");
  const [chatPrompt, setChatPrompt] = useState("");
  const [chatAnswer, setChatAnswer] = useState<string | null>(null);
  const [selectedOpportunity, setSelectedOpportunity] = useState<string | null>(null);
  const [savedOpportunities, setSavedOpportunities] = useState<string[]>([]);
  const [onboardingStep, setOnboardingStep] = useState(0);

  const isPlayer = role === "player";
  const data: CareerData = isPlayer ? {
    greeting: "Hello Thabo",
    journey: "Your player journey",
    profile: 78 + profileBoost,
    development: 64,
    readiness: 72,
    identity: "Rugby wing · U18 · Pretoria",
    premium: "Included with AI Coach Player - R50/month",
    priority: "Improve defensive decision-making.",
    action: "Complete your approved highlight portfolio.",
    goal: "Become a provincial rugby player.",
    profileItems: [["Primary sport and position", "Rugby · Wing", "USER PROVIDED"], ["Current club", "Riverside Rugby Club", "USER PROVIDED"], ["Training development", "Speed and finishing programme", "AI ASSESSMENT"], ["Achievements and videos", "2 items need your approval", "USER PROVIDED"]],
    opportunities: [
      ["Illustrative U18 rugby development programme", "Opportunity record to verify", "Pretoria", 92, "Strong match - confirm eligibility"],
      ["Illustrative university sport pathway", "Opportunity record to verify", "Gauteng", 89, "Good match - add academic record"],
      ["Illustrative academy expression of interest", "Opportunity record to verify", "South Africa", 84, "Potential match - add approved highlights"],
    ],
  } : {
    greeting: "Hello Coach",
    journey: "Your coaching journey",
    profile: 71 + profileBoost,
    development: 68,
    readiness: 75,
    identity: "Rugby coach · Development level · Gauteng",
    premium: "Included with AI Coach Pro - R100/month",
    priority: "Complete a recommended advanced coaching qualification.",
    action: "Update your coaching portfolio and philosophy.",
    goal: "Progress to a provincial development coaching role.",
    profileItems: [["Coaching role and sport", "Rugby · Development coach", "USER PROVIDED"], ["Experience record", "Teams and session plans", "USER PROVIDED"], ["Development pathway", "Qualification and mentorship priorities", "AI ASSESSMENT"], ["Certificates and references", "Upload for review", "USER PROVIDED"]],
    opportunities: [
      ["Illustrative development coach role", "Opportunity record to verify", "Gauteng", 95, "Strong match - qualification check needed"],
      ["Illustrative academy coach opening", "Opportunity record to verify", "Pretoria", 91, "Good match - add coaching portfolio"],
      ["Illustrative youth coaching exchange", "Opportunity record to verify", "International", 86, "Potential match - confirm work eligibility"],
    ],
  };

  const profileCompletion = Math.min(data.profile, 100);
  const onboardingQuestions = isPlayer
    ? ["What is your biggest sporting career goal?", "Which skills are you strongest in right now?", "What would you most like to improve next?"]
    : ["What coaching role are you working toward?", "Which coaching strength are you most proud of?", "Which qualification or experience gap should we plan for next?"];

  const saveOpportunity = (name: string) => {
    setSavedOpportunities((items) => items.includes(name) ? items : [...items, name]);
    showToast("Opportunity saved. Check the official source before applying.");
  };

  const advanceOnboarding = () => {
    setProfileBoost((value) => Math.min(value + 4, 18));
    setOnboardingStep((step) => (step + 1) % onboardingQuestions.length);
    showToast("Profile response saved as user-provided information.");
  };

  const askCareerAgent = (event: FormEvent) => {
    event.preventDefault();
    if (!chatPrompt.trim()) return;
    setChatAnswer(`${data.greeting}, based on your current profile, your next useful step is to ${data.action.toLowerCase()} This is an AI recommendation based on the user-provided and approved information in this demo, not a guarantee of selection or employment.`);
    setChatPrompt("");
  };

  const profileStatusClass = (status: string) => status === "AI ASSESSMENT" ? "status-ai" : "status-user";

  return (
    <div className="page-stack career-agent-page">
      <section className="career-hero">
        <div><p className="eyebrow eyebrow-gold">Career & Development Agent</p><h1>Build your profile. Develop your potential. Discover your opportunity.</h1><p>Your profile is more than a record. It is a practical, controlled way to understand where you are, plan what comes next and prepare for opportunities you choose to pursue.</p><span className="career-premium"><Sparkles size={15} /> {data.premium}</span></div>
        <div className="career-role-select"><p>Choose your journey</p><div><button className={isPlayer ? "active" : ""} onClick={() => { setRole("player"); setTab("dashboard"); }}><Dumbbell size={18} /> Player</button><button className={!isPlayer ? "active" : ""} onClick={() => { setRole("coach"); setTab("dashboard"); }}><Target size={18} /> Coach</button></div><small>Career recommendations adapt to your role. They are guidance, not a promise of selection, employment or sporting success.</small></div>
      </section>

      <div className="career-tabs" role="tablist" aria-label="Career Agent sections">
        {careerTabs.map((item) => <button key={item.id} role="tab" aria-selected={tab === item.id} className={tab === item.id ? "active" : ""} onClick={() => setTab(item.id)}><item.icon size={16} />{item.label}</button>)}
      </div>

      {tab === "dashboard" && <section className="career-dashboard">
        <div className="career-intro"><p className="eyebrow">{data.journey}</p><h2>{data.greeting}, what is your next opportunity?</h2><p>{data.identity}</p><button className="text-button" onClick={() => setTab("profile")}>Complete your profile <ArrowRight size={16} /></button></div>
        <div className="career-scores"><Metric label="Profile completion" value={`${profileCompletion}%`} detail="User-provided profile details" tone="wine" /><Metric label="Development progress" value={`${data.development}%`} detail="Personal progress indicator" /><Metric label="Career readiness" value={`${data.readiness}%`} detail="AI assessment, not a ranking" tone="gold" /></div>
        <div className="career-priority"><span><Sparkles size={20} /></span><div><p className="eyebrow">Next development priority</p><strong>{data.priority}</strong><p>Recommended next action: {data.action}</p></div><button className="button button-wine" onClick={() => setTab("development")}>View development plan <ArrowRight size={16} /></button></div>
        <div className="career-opportunity-preview"><div className="surface-heading"><div><p className="eyebrow">Top opportunities</p><h2>Relevant opportunities to review</h2></div><button className="text-button" onClick={() => setTab("opportunities")}>See all opportunities <ArrowRight size={16} /></button></div>{data.opportunities.slice(0, 3).map(([title, organisation, location, score, next]) => <article key={title}><div><span className="match-number">{score}%</span><div><h3>{title}</h3><p><MapPin size={14} /> {location} · {organisation}</p></div></div><span className="match-note">{next}</span><button className="text-button" onClick={() => setSelectedOpportunity(title)}>Review <ChevronRight size={16} /></button></article>)}</div>
      </section>}

      {tab === "profile" && <section className="career-profile-layout">
        <div className="surface profile-progress"><div className="surface-heading"><div><p className="eyebrow">Professional profile</p><h2>Make your experience usable.</h2></div><span className="profile-ring"><b>{profileCompletion}%</b></span></div><p>Your profile is built progressively. Complete the details you are comfortable sharing, then decide who can see them.</p><div className="profile-question"><span>PROFILE BUILDER · QUESTION {onboardingStep + 1}</span><strong>{onboardingQuestions[onboardingStep]}</strong><button className="button button-wine" onClick={advanceOnboarding}>Save response <Check size={16} /></button></div><Disclaimer>Information is labelled as user-provided until an authorised club or organisation verifies it. AI analysis is never shown as verified fact.</Disclaimer></div>
        <div className="surface profile-records"><div className="surface-heading"><div><p className="eyebrow">Profile record</p><h2>{isPlayer ? "Player profile" : "Coach profile"}</h2></div><button className="text-button" onClick={() => showToast("Profile edit mode opened.")}>Edit profile <Settings size={15} /></button></div><div className="verification-legend"><span className="status status-user">User provided</span><span className="status status-ai">AI assessment</span><span className="status">Verification can be requested</span></div>{data.profileItems.map(([label, value, status]) => <div className="profile-record" key={label}><span>{label}</span><strong>{value}</strong><em className={`status ${profileStatusClass(status)}`}>{status}</em></div>)}</div>
      </section>}

      {tab === "development" && <section className="career-development-layout">
        <div className="surface goal-plan"><p className="eyebrow">Career goal</p><h2>{data.goal}</h2><div className="goal-timeline"><article><span>7 days</span><strong>Complete one profile improvement</strong><p>Add approved experience, achievement or qualification detail.</p></article><article><span>30 days</span><strong>Build evidence of progress</strong><p>Review training, session or development work with a coach or mentor.</p></article><article><span>90 days</span><strong>Prepare for an opportunity</strong><p>Update CV, portfolio and eligible opportunity preferences.</p></article><article><span>Long-term</span><strong>Advance the pathway</strong><p>Target experience, qualifications and opportunities that support the goal.</p></article></div></div>
        <aside className="surface development-assessment"><p className="eyebrow">AI profile analysis</p><h2>Readiness with context.</h2><div className="assessment-row"><strong>Strengths</strong><span>{isPlayer ? "Speed focus · commitment · team participation" : "Session planning · player development · team communication"}</span></div><div className="assessment-row"><strong>Development area</strong><span>{data.priority}</span></div><div className="assessment-row"><strong>Recommended next step</strong><span>{data.action}</span></div><VerifiedTag>AI assessment - review with a qualified mentor</VerifiedTag><button className="button button-outline" onClick={() => navigate(isPlayer ? "player" : "coach")}>Open {isPlayer ? "AI Coach Player" : "AI Coach Pro"} <ArrowRight size={16} /></button></aside>
      </section>}

      {tab === "opportunities" && <section className="career-opportunities">
        <div className="opportunity-filters"><div><p className="eyebrow">Opportunity finder</p><h2>Find what fits your real profile.</h2></div><select aria-label="Opportunity type"><option>{isPlayer ? "Player opportunities" : "Coach opportunities"}</option><option>Clubs and academies</option><option>Courses and qualifications</option><option>Local opportunities</option><option>International opportunities</option></select><select aria-label="Location"><option>All locations</option><option>Pretoria</option><option>Gauteng</option><option>South Africa</option><option>International</option></select></div>
        <div className="opportunity-results">{data.opportunities.map(([title, organisation, location, score, next]) => <article key={title} className="surface career-opportunity"><div className="opportunity-score"><span>AI MATCH</span><strong>{score}%</strong></div><div className="opportunity-main"><div><span className="status status-ai">AI RECOMMENDATION</span><span className="status status-warning">UNVERIFIED</span></div><h3>{title}</h3><p><MapPin size={14} /> {location} · {organisation}</p><ul><li><Check size={15} />Sport and role align with your profile</li><li><Check size={15} />Career goal alignment assessed</li><li><CircleHelp size={15} />Gap: {next}</li></ul></div><div className="opportunity-actions"><button className="button button-outline" onClick={() => saveOpportunity(title)}>{savedOpportunities.includes(title) ? "Saved" : "Save"}</button><button className="button button-wine" onClick={() => setSelectedOpportunity(title)}>Prepare application <ArrowRight size={16} /></button></div></article>)}</div>
        <Disclaimer>These are illustrative opportunity records in this prototype. Always confirm the official organisation, eligibility, deadline, status and application method before applying. The agent never invents opportunities or contacts.</Disclaimer>
      </section>}

      {tab === "applications" && <section className="career-applications">
        <div className="surface applications-table"><div className="surface-heading"><div><p className="eyebrow">My applications</p><h2>Prepare, approve, apply and track.</h2></div><button className="button button-outline" onClick={() => setSelectedOpportunity(data.opportunities[0][0])}><Plus size={16} /> Create application</button></div><div className="table-wrap"><table><thead><tr><th>Opportunity</th><th>Organisation</th><th>Status</th><th>Next action</th></tr></thead><tbody><tr><td>Saved profile opportunity</td><td>Official source required</td><td><span className="status status-warning">Preparing</span></td><td>Confirm eligibility</td></tr><tr><td>Portfolio update</td><td>Personal record</td><td><span className="status status-user">Saved</span></td><td>Add approval for media</td></tr></tbody></table></div></div>
        {selectedOpportunity && <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="application-builder"><div><p className="eyebrow">Application assistant</p><h2>{selectedOpportunity}</h2><p>Prepare a CV, profile summary and application email using approved user-provided information. Nothing is sent until you manually approve it.</p></div><div className="application-documents"><span><FileText size={17} /> Digital {isPlayer ? "sporting" : "coaching"} CV</span><span><FileText size={17} /> Personal statement</span><span><FileText size={17} /> Application email</span></div><div><button className="button button-gold" onClick={() => showToast("Application draft prepared for your review.")}>Build application draft <Sparkles size={16} /></button><button className="text-button" onClick={() => setSelectedOpportunity(null)}>Close draft</button></div></motion.div>}
      </section>}

      {tab === "portfolio" && <section className="career-portfolio-layout">
        <div className="surface portfolio-preview"><div className="portfolio-avatar">{isPlayer ? "TM" : "CP"}</div><div><p className="eyebrow">Shareable {isPlayer ? "player" : "coach"} portfolio</p><h2>{isPlayer ? "Thabo Mokoena" : "Coach profile"}</h2><p>{data.identity}</p><div className="portfolio-tags"><span>Profile</span><span>Achievements</span><span>Experience</span><span>Approved media</span><span>Qualifications</span></div></div><VerifiedTag>User controls visibility</VerifiedTag></div>
        <div className="surface portfolio-actions"><p className="eyebrow">Portfolio controls</p><h2>Share only when you are ready.</h2><div><button className="button button-wine" onClick={() => showToast("Secure profile link copied.")}><Link2 size={16} /> Copy secure link</button><button className="button button-outline" onClick={() => showToast("Portfolio CV export prepared.")}><FileText size={16} /> Download CV</button><button className="button button-outline" onClick={() => showToast("Share options opened.")}><Share2 size={16} /> Share</button></div><p className="media-note"><Video size={16} />Highlight and coaching clips must be reviewed and approved by the user before publishing. AI assistance can organise clips, but does not claim a skill without reliable evidence.</p></div>
      </section>}

      {tab === "chat" && <section className="surface career-chat"><div className="surface-heading"><div><p className="eyebrow">AI Career Chat</p><h2>Ask about your next step.</h2></div><Bot size={23} /></div><p>Try: “Build my CV”, “What should I improve?”, “Why am I a good match?” or “What qualification should I get next?”</p>{chatAnswer && <div className="career-chat-answer"><Bot size={18} /><p>{chatAnswer}</p></div>}<form className="assistant-form" onSubmit={askCareerAgent}><input value={chatPrompt} onChange={(event) => setChatPrompt(event.target.value)} placeholder="Ask your Career & Development Agent..." /><button type="submit" aria-label="Ask career agent"><Send size={18} /></button></form><Disclaimer>The agent uses approved profile information in this workspace. Recommendations are guidance, not guarantees. Verify opportunities and obtain qualified support for safeguarding, legal, medical or employment decisions.</Disclaimer></section>}

      {tab === "privacy" && <section className="career-privacy-layout">
        <div className="surface privacy-settings"><div className="surface-heading"><div><p className="eyebrow">Privacy and discoverability</p><h2>Stay in control of your profile.</h2></div>{discoverable ? <Eye size={22} /> : <EyeOff size={22} />}</div><div className="privacy-control"><div><strong>Available for opportunities</strong><p>Allow eligible clubs, academies and organisations to request contact through the platform.</p></div><button className={`privacy-toggle ${discoverable ? "active" : ""}`} aria-pressed={discoverable} onClick={() => setDiscoverable((active) => !active)}><span /></button></div><label>Profile visibility<select value={visibility} onChange={(event) => setVisibility(event.target.value)}><option>Private</option><option>Club only</option><option>Verified opportunities</option><option>Public</option></select></label><Disclaimer>{isPlayer ? "This demo profile represents a minor. Guardian approval, communication controls and video permissions should be required before recruiter contact or public discoverability." : "Private contact information is not shared until the user gives explicit permission."}</Disclaimer></div>
        <aside className="surface verification-panel"><p className="eyebrow">Verification system</p><h2>Clear labels build trust.</h2><div><span className="status status-success">VERIFIED</span><p>Confirmed by an authorised club, organisation or platform process.</p></div><div><span className="status status-user">USER PROVIDED</span><p>Shared by the user and not independently confirmed.</p></div><div><span className="status status-ai">AI ASSESSMENT</span><p>Generated analysis or a recommendation, never a verified fact.</p></div><button className="button button-outline" onClick={() => showToast("Verification request saved for club review.")}>Request verification <ShieldCheck size={16} /></button></aside>
      </section>}
    </div>
  );
}

type StudioStatus = "Draft" | "Scheduled" | "Published" | "Successful" | "Needs improvement";
type StudioSection = "production" | "library" | "engine" | "automation";
type StudioPreview = "script" | "storyboard" | "thumbnail" | "metadata" | "subtitles" | "voice";
type PublishingMode = "Draft" | "Schedule" | "Auto-publish" | "Manual approval";
type StudioVideo = {
  id: string;
  title: string;
  category: string;
  status: StudioStatus;
  duration: string;
  views: number;
  watchTime: string;
  engagement: number;
  subscribers: number;
  score: number;
  published: string;
  format: "Long-form" | "Short" | "Series";
};

const initialStudioVideos: StudioVideo[] = [
  { id: "studio-1", title: "What is Coach Player Clubhouse?", category: "Platform introduction", status: "Draft", duration: "4:58", views: 0, watchTime: " - ", engagement: 0, subscribers: 0, score: 0, published: "Not published", format: "Long-form" },
  { id: "studio-2", title: "Find Sponsors with AI", category: "Sponsorship", status: "Scheduled", duration: "5:12", views: 0, watchTime: " - ", engagement: 0, subscribers: 0, score: 0, published: "Scheduled 05 Sep", format: "Long-form" },
  { id: "studio-3", title: "How Teams Can Pay Their Players", category: "Finance", status: "Successful", duration: "5:04", views: 1240, watchTime: "3:42", engagement: 14.8, subscribers: 34, score: 88, published: "12 Aug 2025", format: "Long-form" },
  { id: "studio-4", title: "Create Your Club for Free", category: "Club management", status: "Published", duration: "4:46", views: 8420, watchTime: "2:58", engagement: 9.2, subscribers: 128, score: 81, published: "29 Jul 2025", format: "Long-form" },
  { id: "studio-5", title: "Build Your Digital Sporting CV", category: "Career", status: "Published", duration: "5:21", views: 3610, watchTime: "3:11", engagement: 11.4, subscribers: 71, score: 76, published: "07 Aug 2025", format: "Long-form" },
  { id: "studio-6", title: "Meet the Career & Development Agent", category: "Career", status: "Draft", duration: "5:00", views: 0, watchTime: " - ", engagement: 0, subscribers: 0, score: 0, published: "Not published", format: "Long-form" },
  { id: "studio-7", title: "Bulk Payments Explained", category: "Finance", status: "Needs improvement", duration: "4:52", views: 760, watchTime: "1:22", engagement: 4.1, subscribers: 5, score: 48, published: "02 Aug 2025", format: "Long-form" },
];

const studioNav: { id: StudioSection; label: string; icon: LucideIcon }[] = [
  { id: "production", label: "Production", icon: Clapperboard },
  { id: "library", label: "Video library", icon: ListVideo },
  { id: "engine", label: "Content engine", icon: TrendingUp },
  { id: "automation", label: "Automation", icon: Settings },
];

const studioScript = [
  ["0:00 – 0:20", "HOOK", "Running a community sports club can feel like running ten different businesses at once."],
  ["0:20 – 0:50", "PROBLEM", "Players, parents, coaches, fixtures, payments and sponsors all need attention. The admin never stops."],
  ["0:50 – 1:30", "INTRODUCTION", "That is why Coach Player Clubhouse brings the club, the team and the support system into one digital home."],
  ["1:30 – 4:20", "FEATURE EXPLANATION", "Start free, invite your people, manage your teams and use the tools that help your club grow. Add AI and payments only when they create value."],
  ["4:20 – 4:45", "BENEFITS", "Less disconnected admin. More time for coaching. A clearer path to funding, opportunity and progress."],
  ["4:45 – 5:00", "CALL TO ACTION", "Create your free clubhouse today. Build your club. Develop your people. Discover what comes next."],
];

const studioScenes = [
  ["01", "Coach at a field with paperwork.", "Running a sports club should not feel like running ten different businesses."],
  ["02", "Paperwork transforms into a clubhouse dashboard.", "That is why we created Coach Player Clubhouse."],
  ["03", "A club profile is created on screen.", "Every club can start free, with no monthly software fee."],
  ["04", "Players, parents and coaches join a team.", "Bring the whole community into one connected place."],
  ["05", "Attendance and schedules animate into view.", "Keep the week organised and give coaches more time to coach."],
  ["06", "A payment confirmation becomes a club summary.", "Collect membership and event payments through clear, transparent checkout."],
  ["07", "A player profile grows into a career pathway.", "AI helps players and coaches develop and discover opportunity."],
  ["08", "A sponsor match appears in the marketplace.", "Connect your club with businesses that want to support community sport."],
  ["09", "Dashboard cards connect into one ecosystem.", "One digital home for the people who make sport happen."],
  ["FINAL", "Coach Player mark with motto.", "Coach Player Clubhouse. The best gift I can give is myself."],
];

const studioIdeas = [
  { title: "How Bulk Player Payments Work", value: "Explains squad-wide payment runs, approval and records — not a repeat of direct player payments.", score: 94, signal: "Strong retention around payment examples" },
  { title: "How Scheduled Payments Work", value: "Shows how clubs can plan recurring membership or allowance payments ahead of time.", score: 89, signal: "Viewers asked about timing and reminders" },
  { title: "How Coaches Receive Club Payments", value: "A distinct coach-facing walkthrough of payment setup, confirmation and reporting.", score: 85, signal: "Coach audience over-indexed on the finance topic" },
  { title: "How Club Payment Records Work", value: "Focuses on receipts, order history and simple reconciliation for club administrators.", score: 81, signal: "Questions about admin and transparency" },
  { title: "How AI Finance Coach Helps Your Club", value: "Connects the successful payments topic to practical cash-flow and follow-up support.", score: 77, signal: "AI feature discovery is a growing search interest" },
];

function VideoStudio({ showToast }: { showToast: (message: string) => void }) {
  const [section, setSection] = useState<StudioSection>("production");
  const [preview, setPreview] = useState<StudioPreview>("script");
  const [videos, setVideos] = useState<StudioVideo[]>(initialStudioVideos);
  const [selectedId, setSelectedId] = useState("studio-1");
  const [connected, setConnected] = useState(false);
  const [publishingMode, setPublishingMode] = useState<PublishingMode>("Manual approval");
  const [automation, setAutomation] = useState<Record<string, boolean>>({
    scripts: true,
    storyboards: true,
    render: true,
    thumbnails: true,
    subtitles: true,
    scheduling: false,
    autoPublish: false,
    analytics: true,
    followups: true,
    shorts: false,
  });
  const [ideasOpen, setIdeasOpen] = useState(false);
  const [shortsCreated, setShortsCreated] = useState<string[]>([]);
  const [voices, setVoices] = useState("Professional / energetic");
  const [newTopic, setNewTopic] = useState("");
  const [libraryFilter, setLibraryFilter] = useState<"All" | StudioStatus>("All");
  const [proposals, setProposals] = useState<string[]>([]);

  const selected = videos.find((video) => video.id === selectedId) ?? videos[0];
  const published = videos.filter((video) => video.status === "Published" || video.status === "Successful");
  const totalViews = published.reduce((sum, video) => sum + video.views, 0);
  const successfulVideos = videos.filter((video) => video.status === "Successful").length;
  const queue = videos.filter((video) => video.status === "Draft" || video.status === "Scheduled" || video.status === "Needs improvement").slice(0, 4);
  const visibleLibrary = libraryFilter === "All" ? videos : videos.filter((video) => video.status === libraryFilter);

  const updateVideo = (id: string, patch: Partial<StudioVideo>) => {
    setVideos((items) => items.map((video) => video.id === id ? { ...video, ...patch } : video));
  };

  const addVideo = (title: string, category = "AI plan", status: StudioStatus = "Draft") => {
    const cleanTitle = title.trim();
    if (!cleanTitle) return;
    const id = `studio-${Date.now()}`;
    setVideos((items) => [{ id, title: cleanTitle, category, status, duration: "5:00", views: 0, watchTime: " - ", engagement: 0, subscribers: 0, score: 0, published: "Not published", format: "Long-form" }, ...items]);
    setSelectedId(id);
    setSection("production");
    setPreview("script");
    setNewTopic("");
    showToast("A 5-minute script, storyboard and production plan were prepared for approval.");
  };

  const approveSelected = () => {
    updateVideo(selected.id, { status: "Scheduled", published: "Scheduled - date to confirm" });
    showToast(connected ? "Video approved and scheduled. Manual approval is still required before publication." : "Video approved and added to the schedule. Connect YouTube before publishing.");
  };

  const publishSelected = () => {
    if (!connected) {
      showToast("Connect the authorised YouTube channel before publishing.");
      return;
    }
    updateVideo(selected.id, { status: "Published", published: "Just now" });
    showToast("Video published through the authorised channel connection.");
  };

  const deleteSelected = () => {
    if (videos.length <= 1) {
      showToast("Keep at least one video in the studio before removing this draft.");
      return;
    }
    setVideos((items) => items.filter((video) => video.id !== selected.id));
    const next = videos.find((video) => video.id !== selected.id);
    setSelectedId(next?.id ?? videos[0].id);
    showToast("Video draft removed from the studio.");
  };

  const toggleAutomation = (key: string) => {
    setAutomation((items) => ({ ...items, [key]: !items[key] }));
  };

  return (
    <div className="page-stack studio-page">
      <section className="studio-hero">
        <div>
          <p className="eyebrow eyebrow-gold">Coach Player AI Video Studio</p>
          <h1>One video. A smarter next video.</h1>
          <p>Plan, write, animate, review and learn from educational videos for the whole sports community. Every publish builds a better content library.</p>
          <div className="studio-hero-actions">
            <button className="button button-gold" onClick={() => addVideo("Why Every Club Should Start Free", "Platform introduction")}>Generate a new video <Sparkles size={16} /></button>
            <button className="button button-ghost" onClick={() => setSection("engine")}>Explore the content engine <TrendingUp size={16} /></button>
          </div>
        </div>
        <aside className="studio-channel">
          <div className="studio-channel-top"><MonitorPlay size={22} /><span>YouTube channel</span><i className={connected ? "connected" : ""}>{connected ? "Connected" : "Not connected"}</i></div>
          <strong>Coach Player Clubhouse</strong>
          <small>@coachplayerclubhouse · Educational sports content</small>
          <button className="button button-gold full-button" onClick={() => { setConnected((value) => !value); showToast(connected ? "YouTube channel disconnected." : "YouTube connection authorised for this demo. No password was stored."); }}>{connected ? "Disconnect channel" : "Connect YouTube channel"} <ExternalLink size={15} /></button>
          <p><LockKeyhole size={13} /> Secure OAuth connection. The channel owner controls access and can disconnect at any time.</p>
        </aside>
      </section>

      <section className="studio-metrics">
        <Metric label="Studio videos" value={String(videos.length).padStart(2, "0")} detail={`${queue.length} in the approval queue`} tone="wine" />
        <Metric label="Demo views" value={totalViews > 999 ? `${(totalViews / 1000).toFixed(1)}k` : String(totalViews)} detail="Sample performance data" />
        <Metric label="Successful videos" value={`${successfulVideos}`} detail="1,000+ view trigger" tone="gold" />
        <Metric label="Publishing mode" value={publishingMode === "Manual approval" ? "Manual" : publishingMode} detail={connected ? "Channel connected" : "Channel not connected"} />
      </section>

      <div className="studio-nav" role="tablist" aria-label="AI Video Studio sections">
        {studioNav.map((item) => <button key={item.id} role="tab" aria-selected={section === item.id} className={section === item.id ? "active" : ""} onClick={() => setSection(item.id)}><item.icon size={16} />{item.label}</button>)}
      </div>

      {section === "production" && (
        <section className="studio-production">
          <div className="studio-pipeline"><span className="active"><Check size={13} />Plan</span><span className="active"><Check size={13} />Script</span><span className="active"><Check size={13} />Storyboard</span><span className="active"><Check size={13} />Thumbnail</span><span><AudioLines size={13} />Voice</span><span><Captions size={13} />Subtitles</span><span><Eye size={13} />Review</span><span><MonitorPlay size={13} />Publish</span></div>
          <div className="studio-workspace">
            <div className="studio-canvas surface">
              <div className="studio-canvas-head"><div><p className="eyebrow">Production preview</p><h2>{selected.title}</h2></div><span className={`status ${selected.status === "Successful" ? "status-success" : selected.status === "Needs improvement" ? "status-warning" : "status-user"}`}>{selected.status}</span></div>
              <div className="studio-screen">
                <div className="studio-screen-top"><span>COACH PLAYER CLUBHOUSE</span><span>{selected.duration}</span></div>
                <div className="studio-screen-graphic"><CoachPlayerMark /><div><span>THE BEST GIFT I CAN GIVE IS MYSELF.</span><strong>{selected.title}</strong></div></div>
                <div className="studio-screen-bottom"><span><Play size={13} /> Animated explainer</span><span>0:00 / {selected.duration}</span><span><Captions size={13} /> CC</span></div>
              </div>
              <div className="studio-timeline-strip">{[["0:00", "Hook"], ["0:20", "Problem"], ["0:50", "Coach Player"], ["1:30", "Feature"], ["4:20", "Benefits"], ["4:45", "CTA"]].map(([time, label]) => <span key={time}><b>{time}</b>{label}</span>)}</div>
              <div className="studio-preview-tabs" role="tablist" aria-label="Production preview sections">{(["script", "storyboard", "thumbnail", "metadata", "subtitles", "voice"] as StudioPreview[]).map((item) => <button key={item} role="tab" aria-selected={preview === item} className={preview === item ? "active" : ""} onClick={() => setPreview(item)}>{item}</button>)}</div>
              <div className="studio-preview-content">
                {preview === "script" && <div className="script-preview"><div className="preview-meta"><span>5-minute script</span><span>Conversational · Community-friendly</span><VerifiedTag>Needs editorial review</VerifiedTag></div>{studioScript.map(([time, label, text]) => <div className="script-row" key={time}><span>{time}</span><strong>{label}</strong><p>{text}</p></div>)}</div>}
                {preview === "storyboard" && <div className="storyboard-preview"><div className="preview-meta"><span>Animated storyboard</span><span>10 scenes · Brand palette</span></div><div className="storyboard-grid">{studioScenes.slice(0, 6).map(([number, visual, narration]) => <article key={number}><span>SCENE {number}</span><div className="storyboard-visual"><Play size={19} /></div><strong>{visual}</strong><p>“{narration}”</p></article>)}</div><button className="text-button" onClick={() => showToast("Full 10-scene storyboard opened.")}>View all 10 scenes <ChevronRight size={15} /></button></div>}
                {preview === "thumbnail" && <div className="thumbnail-preview"><div className="preview-meta"><span>Thumbnail concept</span><span><ImageIcon size={13} /> Readable · Brand consistent</span></div><div className="thumbnail-canvas"><span>COACH PLAYER CLUBHOUSE</span><strong>{selected.title}</strong><small>FREE FOR CLUBS <ArrowRight size={14} /></small><div className="thumbnail-rings" /></div><p className="studio-fineprint"><ShieldCheck size={14} /> AI-generated concept. Check that the title, claims and artwork are accurate before publishing.</p><button className="button button-outline" onClick={() => showToast("New thumbnail direction generated for review.")}><RefreshCw size={15} /> Regenerate direction</button></div>}
                {preview === "metadata" && <div className="metadata-preview"><div className="preview-meta"><span>YouTube metadata</span><span>Editable before approval</span></div><label>Title<input defaultValue={selected.title} /></label><label>Description<textarea defaultValue={`Coach Player Clubhouse helps players, coaches and clubs connect, develop and grow. Learn more about this feature and start your free clubhouse today.\n\nOfficial links and up-to-date product information are configured by the channel owner.`} rows={4} /></label><label>Call to action<select defaultValue="Create your free clubhouse"><option>Create your free clubhouse</option><option>Build your player profile</option><option>Create your coaching profile</option><option>Try AI Coach Player</option><option>Find your next opportunity</option><option>Connect your club with sponsors</option></select></label><div className="metadata-tags"><span>Club management</span><span>Sports AI</span><span>Grassroots sport</span><span>Coach Player Clubhouse</span></div><button className="button button-outline" onClick={() => showToast("Metadata regenerated for editorial review.")}><Sparkles size={15} /> Regenerate metadata</button></div>}
                {preview === "subtitles" && <div className="subtitle-preview"><div className="preview-meta"><span>Captions</span><span>Auto-synchronised draft</span><VerifiedTag>Review for accuracy</VerifiedTag></div>{[["00:00", "Running a community sports club can feel like running ten businesses at once."], ["00:05", "That is why Coach Player Clubhouse brings the club into one digital home."], ["00:11", "Start free, invite your people and build the club you want to see."]].map(([time, line]) => <div className="subtitle-row" key={time}><b>{time}</b><span>{line}</span><button onClick={() => showToast("Caption line opened for editing.")}><Pencil size={13} /></button></div>)}<div className="subtitle-actions"><button className="button button-outline" onClick={() => showToast("SRT subtitle file prepared.")}><DownloadIcon /> SRT</button><button className="button button-outline" onClick={() => showToast("VTT subtitle file prepared.")}>VTT</button><button className="button button-outline" onClick={() => showToast("Burned-in caption render queued.")}>Burned-in captions</button></div></div>}
                {preview === "voice" && <div className="voice-preview"><div className="preview-meta"><span>Voice-over studio</span><VerifiedTag>AI narration draft</VerifiedTag></div><div className="voice-wave">{[28, 44, 18, 53, 34, 62, 23, 46, 58, 30, 42, 20, 56, 36, 48, 25, 61, 40, 29, 51].map((height, index) => <i key={index} style={{ height: `${height}%` }} />)}</div><div className="voice-controls"><label>Voice<select value={voices} onChange={(event) => setVoices(event.target.value)}><option>Professional / energetic</option><option>Friendly / warm</option><option>Clear / measured</option></select></label><label>Language<select defaultValue="English"><option>English</option><option>isiZulu</option><option>Afrikaans</option><option>Sesotho</option></select></label><label>Accent<select defaultValue="South African"><option>South African</option><option>Neutral international</option><option>British</option></select></label><label>Speed<select defaultValue="1.0x"><option>0.9x</option><option>1.0x</option><option>1.1x</option></select></label></div><div className="voice-actions"><button className="button button-gold" onClick={() => showToast("Voice-over preview generated. Review before rendering.")}><Play size={15} /> Preview narration</button><button className="text-button" onClick={() => showToast("Voice settings saved for this series.")}>Save voice style <Check size={15} /></button></div><Disclaimer>Voice generation is a draft in this prototype. Use the channel owner&apos;s approved voice and brand settings before publishing.</Disclaimer></div>}
              </div>
              <div className="studio-approval-bar"><span><LockKeyhole size={14} /> Manual approval is the default. Nothing is published without explicit action.</span><div><button className="button button-outline" onClick={() => showToast("Video editor opened.")}><Pencil size={15} /> Edit</button><button className="button button-outline" onClick={() => showToast("A new generation has been queued for review.")}><RefreshCw size={15} /> Regenerate</button><button className="button button-outline" onClick={deleteSelected}><Trash2 size={15} /> Delete</button><button className="button button-wine" onClick={approveSelected}>Approve & schedule <Check size={15} /></button><button className="button button-gold" onClick={publishSelected}>Publish now <MonitorPlay size={15} /></button></div></div>
            </div>

            <aside className="studio-queue">
              <div className="surface studio-queue-card"><div className="surface-heading"><div><p className="eyebrow">Approval queue</p><h2>Ready for a human.</h2></div><span className="queue-count">{queue.length}</span></div><div className="queue-list">{queue.map((video) => <button key={video.id} className={video.id === selected.id ? "active" : ""} onClick={() => { setSelectedId(video.id); setPreview("script"); }}><span className={`queue-dot ${video.status.toLowerCase().replace(/ /g, "-")}`} /><span><strong>{video.title}</strong><small>{video.category} · {video.duration}</small></span><ChevronRight size={15} /></button>)}</div><button className="button button-wine full-button" onClick={() => addVideo("How Club Announcements Keep Everyone Connected", "Communication")}><Plus size={15} /> Generate another video</button></div>
              <div className="surface brand-voice-card"><p className="eyebrow">Brand kit</p><h2>Voice of the clubhouse.</h2><div className="brand-swatch-row"><span /><span /><span /><span /></div><p>Burgundy, gold and cream. Clear, energetic and human.</p><div className="brand-standard"><span><LayoutTemplate size={15} /> Standard intro</span><span><AudioLines size={15} /> Professional / warm</span><span><Captions size={15} /> Captions on by default</span></div><button className="text-button" onClick={() => showToast("Full brand and template kit opened.")}>Open brand kit <ExternalLink size={14} /></button></div>
            </aside>
          </div>
        </section>
      )}

      {section === "library" && (
        <section className="studio-library">
          <div className="library-heading"><div><p className="eyebrow">Video library</p><h2>Every video, every signal, one place.</h2><p>Drafts, scheduled videos, published education, successful topics and content series.</p></div><div className="library-actions"><input value={newTopic} onChange={(event) => setNewTopic(event.target.value)} placeholder="Add a video topic..." aria-label="New video topic" /><button className="button button-wine" onClick={() => addVideo(newTopic || "A new clubhouse explainer", "Club education")}><Plus size={15} /> Generate video</button></div></div>
          <div className="library-filters" role="group" aria-label="Filter library by status">{(["All", "Draft", "Scheduled", "Published", "Successful", "Needs improvement"] as ("All" | StudioStatus)[]).map((filter) => <button key={filter} className={libraryFilter === filter ? "active" : ""} onClick={() => setLibraryFilter(filter)}>{filter === "Draft" ? "Drafts" : filter}</button>)}</div>
          <div className="surface studio-table">{visibleLibrary.length ? <div className="table-wrap"><table><thead><tr><th>Video</th><th>Status</th><th>Views</th><th>Watch time</th><th>Engagement</th><th>Subscribers</th><th>Performance</th><th /></tr></thead><tbody>{visibleLibrary.map((video) => <tr key={video.id}><td><strong>{video.title}</strong><small>{video.category} · {video.published}</small></td><td><span className={`status ${video.status === "Successful" ? "status-success" : video.status === "Needs improvement" ? "status-warning" : video.status === "Draft" ? "status-user" : ""}`}>{video.status}</span></td><td>{video.views ? video.views.toLocaleString() : " - "}</td><td>{video.watchTime}</td><td>{video.engagement ? `${video.engagement}%` : " - "}</td><td>{video.subscribers ? `+${video.subscribers}` : " - "}</td><td><span className="score-cell">{video.score ? `${video.score}/100` : "Awaiting publish"}</span></td><td><button className="table-action" aria-label={`Open ${video.title}`} onClick={() => { setSelectedId(video.id); setSection("production"); setPreview("script"); }}><Eye size={16} /></button></td></tr>)}</tbody></table></div> : <div className="studio-empty"><Clapperboard size={28} /><p>No videos in this view yet.</p></div>}</div>
          <div className="library-lower">
            <div className="surface shorts-panel"><div className="surface-heading"><div><p className="eyebrow">Short-form generator</p><h2>Find the strongest moments.</h2></div><Play size={21} /></div><p>Turn any approved explainer into short vertical clips without auto-publishing to external platforms.</p><div className="shorts-options">{[["15s", "Hook moment"], ["30s", "Feature moment"], ["60s", "Best explanation"]].map(([length, label]) => <button key={length} onClick={() => { setShortsCreated((items) => items.includes(length) ? items : [...items, length]); showToast(`${length} short prepared for review. External publishing is not connected.`); }} className={shortsCreated.includes(length) ? "created" : ""}><strong>{length}</strong><span>{label}</span>{shortsCreated.includes(length) ? <Check size={15} /> : <Plus size={15} />}</button>)}</div><small><ShieldCheck size={13} /> Separate authorisation is required for TikTok, Instagram and Facebook.</small></div>
            <div className="surface series-panel"><div className="surface-heading"><div><p className="eyebrow">Series generator</p><h2>Build Your Club with Coach Player</h2></div><ListVideo size={21} /></div><div className="series-episodes">{[["01", "Start Your Club for Free"], ["02", "Create Your Club Website"], ["03", "Register Your Players"], ["04", "Collect Payments"], ["05", "Find Sponsors"]].map(([number, title]) => <span key={number}><b>{number}</b>{title}<CheckCircle2 size={14} /></span>)}</div><button className="text-button" onClick={() => showToast("The full eight-episode series plan has been saved.")}>Plan all 8 episodes <ArrowRight size={15} /></button></div>
          </div>
        </section>
      )}

      {section === "engine" && (
        <section className="studio-engine">
          <div className="engine-trigger">
            <div className="trigger-badge"><TrendingUp size={20} /><span>1,000+ VIEW TRIGGER</span></div>
            <div><p className="eyebrow">Successful video detected</p><h2>&ldquo;How Teams Can Pay Their Players&rdquo; crossed 1,000 views.</h2><p>Coach Player AI has analysed the topic signal and generated a ranked set of distinct follow-up videos. Publishing stays in manual approval by default.</p><div className="trigger-stats"><span><strong>1,240</strong>Views</span><span><strong>3:42</strong>Avg. view duration</span><span><strong>14.8%</strong>Engagement</span><span><strong>+34</strong>Subscribers</span></div><button className="button button-gold" onClick={() => setIdeasOpen(true)}><Sparkles size={16} /> Generate 5 follow-up ideas</button></div>
          </div>
          {ideasOpen && <div className="followup-section"><div className="followup-head"><p className="eyebrow">AI content expansion</p><h2>Ranked follow-up opportunities</h2><p>Each recommendation must add distinct practical value. The AI never duplicates the parent video.</p></div><div className="followup-list">{studioIdeas.map((idea, index) => <article key={idea.title}><span className="idea-rank">0{index + 1}</span><div><div className="idea-meta"><span>{index === 0 ? "BEST NEXT VIDEO" : `RANK ${index + 1}`}</span><strong>{idea.score}% opportunity score</strong></div><h3>{idea.title}</h3><p>{idea.value}</p><small><TrendingUp size={13} /> {idea.signal}</small></div><button className="button button-outline" onClick={() => addVideo(idea.title, "Content expansion")}>Build script <ArrowRight size={15} /></button></article>)}</div></div>}
          <div className="studio-loop"><span>THE LEARNING LOOP</span>{["Create", "Edit", "Review", "Publish", "Analyse", "Learn", "Create more"].map((step, index) => <div key={step}><b>{String(index + 1).padStart(2, "0")}</b>{step}{index < 6 && <ArrowRight size={13} />}</div>)}</div>
          <div className="content-tree-grid">
            <div className="surface content-tree"><div className="surface-heading"><div><p className="eyebrow">Content tree</p><h2>Build depth, not repetition.</h2></div><BarChart3 size={21} /></div><div className="tree-root"><span>PARENT VIDEO</span><strong>Coach Player Payments</strong><small>1,240 views · successful topic</small></div><div className="tree-branches"><div><span>Individual payments</span><span>Bulk payments</span><span>Scheduled payments</span><span>Recurring payments</span></div><div><span>Player allowances</span><span>Coach payments</span><span>Payment reports</span><span>AI Finance Coach</span></div></div></div>
            <div className="surface analytics-panel"><div className="surface-heading"><div><p className="eyebrow">Performance signals</p><h2>Learn from what worked.</h2></div><BarChart3 size={21} /></div><p className="demo-label">Demo analytics · not live YouTube data</p>{[["How Teams Can Pay Their Players", 88, "success"], ["Create Your Club for Free", 81, ""], ["Build Your Digital Sporting CV", 76, ""], ["Bulk Payments Explained", 48, "needs"]].map(([title, score, kind]) => <div className="performance-row" key={String(title)}><span>{title}</span><i><b className={kind === "success" ? "success" : kind === "needs" ? "needs" : ""} style={{ width: `${score}%` }} /></i><strong>{score}</strong></div>)}<div className="analytics-note"><ThumbsUp size={15} />The AI prioritises engagement and retention signals, not views alone.</div></div>
          </div>
          <div className="engine-lower">
            <div className="surface comment-intelligence"><div className="surface-heading"><div><p className="eyebrow">Comment intelligence</p><h2>Questions become useful content.</h2></div><MessageSquare size={21} /></div><div className="comment-list"><article><span>QUESTION</span><p>&ldquo;Can clubs pay players directly?&rdquo;</p><small>× 9 similar comments</small></article><article><span>CONFUSION</span><p>&ldquo;I am still unsure how the service fee works.&rdquo;</p><small>× 5 similar comments</small></article><article><span>FEATURE REQUEST</span><p>&ldquo;Could we pay coaches through the club too?&rdquo;</p><small>× 3 similar comments</small></article></div><button className="button button-wine" onClick={() => { if (!proposals.includes("Yes - here's how Coach Player Pay works")) { setProposals((items) => [...items, "Yes - here's how Coach Player Pay works"]); } showToast("Video proposal created from audience questions. Comment replies stay under human review."); }}>Create video from questions <Sparkles size={16} /></button>{proposals.length > 0 && <div className="proposal-created"><CheckCircle2 size={16} /> {proposals.length} proposal added to the production queue</div>}</div>
            <div className="surface studio-calendar"><div className="surface-heading"><div><p className="eyebrow">Content calendar</p><h2>A rhythm the channel can keep.</h2></div><CalendarClock size={21} /></div><div className="calendar-week">{[["MON", "Club feature", "Create Your Club for Free"], ["WED", "AI feature", "Meet the Career Agent"], ["FRI", "Development", "How AI Coach Pro Helps"], ["SUN", "Business", "Find Sponsors with AI"]].map(([day, type, title]) => <article key={day}><span>{day}</span><small>{type}</small><strong>{title}</strong><button className="text-button" onClick={() => setSection("production")}>Open <ChevronRight size={14} /></button></article>)}</div><button className="text-button" onClick={() => showToast("AI content calendar refreshed for the next four weeks.")}>Refresh AI schedule <RefreshCw size={15} /></button></div>
          </div>
        </section>
      )}

      {section === "automation" && (
        <section className="studio-automation">
          <div className="automation-layout">
            <div className="surface publishing-card"><div className="surface-heading"><div><p className="eyebrow">YouTube connection and publishing</p><h2>The owner stays in control.</h2></div>{connected ? <CheckCircle2 size={22} /> : <LockKeyhole size={22} />}</div><div className={`channel-status ${connected ? "on" : ""}`}><MonitorPlay size={19} /><div><strong>Coach Player Clubhouse</strong><small>{connected ? "Authorised YouTube connection active" : "No YouTube channel connected"}</small></div><button className="text-button" onClick={() => { setConnected((value) => !value); showToast(connected ? "YouTube channel disconnected." : "YouTube connection authorised for this demo. No passwords were stored."); }}>{connected ? "Disconnect" : "Connect"}</button></div><p className="publishing-copy">Publishing modes control what happens after a production package is approved. Manual approval remains the safe default.</p>{(["Draft", "Schedule", "Auto-publish", "Manual approval"] as PublishingMode[]).map((mode) => <button key={mode} className={`publishing-mode ${publishingMode === mode ? "active" : ""}`} onClick={() => { setPublishingMode(mode); showToast(`${mode} selected. Changes are saved to channel settings.`); }}><span className="mode-radio" /><span><strong>{mode}</strong><small>{mode === "Manual approval" ? "Recommended: prepare automatically, publish only after human approval." : mode === "Auto-publish" ? "Only available after the owner explicitly enables it and approves the series." : mode === "Schedule" ? "Place approved content on the content calendar." : "Keep everything as a draft until you choose otherwise."}</small></span>{publishingMode === mode && <Check size={16} />}</button>)}<div className="authorisation-note"><ShieldCheck size={16} /><span>Secure OAuth only. The channel owner grants permission and can revoke access at any time. This prototype simulates the connection.</span></div></div>
            <div className="surface automation-settings"><div className="surface-heading"><div><p className="eyebrow">Automation settings</p><h2>Generate freely. Publish deliberately.</h2></div><Settings size={21} /></div><div className="toggle-list">{([["scripts", "Generate scripts"], ["storyboards", "Create storyboards"], ["render", "Render animated videos"], ["thumbnails", "Generate thumbnails"], ["subtitles", "Generate subtitles"], ["analytics", "Analyse performance"], ["followups", "Generate follow-up videos"], ["scheduling", "Schedule approved videos"], ["shorts", "Create short-form clips"], ["autoPublish", "Auto-publish approved content"]] as [string, string][]).map(([key, label]) => <div className="automation-row" key={key}><span>{label}</span><button aria-pressed={automation[key]} className={`privacy-toggle ${automation[key] ? "active" : ""}`} onClick={() => toggleAutomation(key)}><span /></button></div>)}</div><p className="automation-default"><LockKeyhole size={14} /> Generation is on by default. Publishing requires explicit approval.</p><button className="button button-wine full-button" onClick={() => showToast("Automation settings saved. Publishing remains manual unless explicitly changed.")}>Save automation settings <Check size={16} /></button></div>
          </div>
          <div className="automation-lower">
            <div className="surface template-card"><div className="surface-heading"><div><p className="eyebrow">Brand consistency</p><h2>Standard intro and outro.</h2></div><LayoutTemplate size={21} /></div><div className="template-preview"><span>COACH PLAYER CLUBHOUSE</span><strong>The best gift I can give is myself.</strong><small>Manage your club. Develop your people. Discover opportunity.</small></div><div className="template-actions"><button className="text-button" onClick={() => showToast("Intro template preview opened.")}>Preview intro <Play size={14} /></button><button className="text-button" onClick={() => showToast("Outro template preview opened.")}>Preview outro <Play size={14} /></button><button className="text-button" onClick={() => showToast("Brand templates saved.")}>Edit templates <Pencil size={14} /></button></div></div>
            <div className="surface voice-defaults"><div className="surface-heading"><div><p className="eyebrow">Voice defaults</p><h2>Clear, warm and energetic.</h2></div><Mic size={21} /></div><label>Default voice<select value={voices} onChange={(event) => setVoices(event.target.value)}><option>Professional / energetic</option><option>Friendly / warm</option><option>Clear / measured</option></select></label><label>Default language<select defaultValue="English"><option>English</option><option>isiZulu</option><option>Afrikaans</option><option>Sesotho</option></select></label><div className="voice-wave small">{[36, 58, 28, 69, 42, 54, 33, 61, 46, 75, 37, 50, 64, 29].map((height, index) => <i key={index} style={{ height: `${height}%` }} />)}</div><p>Voice style is stored for every new explainer. Review pronunciation and local language use before publishing.</p></div>
          </div>
          <div className="surface studio-safety"><div><p className="eyebrow">Quality and safety rules</p><h2>Make useful education, not empty claims.</h2></div><div className="safety-rules"><span><Check size={15} />No fake statistics, customers, testimonials or partnerships</span><span><Check size={15} />Label current, planned and demo features clearly</span><span><Check size={15} />No misleading titles or thumbnails</span><span><Check size={15} />Respect YouTube policies and API limits</span><span><Check size={15} />Publish only through an authorised account</span></div><VerifiedTag>Prototype content, analytics and connections are illustrative</VerifiedTag></div>
        </section>
      )}
    </div>
  );
}

function DownloadIcon() {
  return <ArrowRight size={15} className="rotate-90" />;
}

export default function App() {
  const [view, setView] = useState<View>("overview");
  const [menuOpen, setMenuOpen] = useState(false);
  const [toast, setToast] = useState<Toast>(null);

  const showToast = (message: string) => setToast({ message, id: Date.now() });
  const navigate = (nextView: View) => { setView(nextView); setMenuOpen(false); window.scrollTo({ top: 0, behavior: "smooth" }); };

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const renderView = () => {
    if (view === "pricing") return <Pricing showToast={showToast} navigate={navigate} />;
    if (view === "growth") return <Growth showToast={showToast} navigate={navigate} />;
    if (view === "finance") return <Finance showToast={showToast} />;
    if (view === "sponsors") return <Sponsors showToast={showToast} />;
    if (view === "documents") return <Documents showToast={showToast} />;
    if (view === "meetings") return <Meetings showToast={showToast} />;
    if (view === "store") return <Store showToast={showToast} />;
    if (view === "player") return <Player showToast={showToast} />;
    if (view === "coach") return <Coach showToast={showToast} />;
    if (view === "career") return <CareerAgent showToast={showToast} navigate={navigate} />;
    if (view === "studio") return <VideoStudio showToast={showToast} />;
    return <Overview navigate={navigate} />;
  };

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="sidebar-brand"><CoachPlayerMark /><span>CLUBHOUSE</span></div>
        <div className="sidebar-club"><div className="club-emblem">RR</div><div><strong>Riverside Rugby Club</strong><small>Club administrator</small></div><ChevronDown size={15} /></div>
        <nav className="sidebar-nav" aria-label="Clubhouse navigation">
          <p>Club operations</p>
          {navigation.map((item) => <button key={item.view} className={view === item.view ? "active" : ""} onClick={() => navigate(item.view)}><item.icon size={18} /><span>{item.label}</span></button>)}
          <p>Training and development</p>
          {coachingNavigation.map((item) => <button key={item.view} className={view === item.view ? "active" : ""} onClick={() => navigate(item.view)}><item.icon size={18} /><span>{item.label}</span>{item.view === "player" && <em>R50</em>}{item.view === "coach" && <em>R100</em>}</button>)}
        </nav>
        <div className="sidebar-bottom"><button onClick={() => showToast("Notifications are all caught up.")}><Bell size={18} />Notifications<span>3</span></button><button onClick={() => showToast("Club settings opened.")}><Settings size={18} />Settings</button><div className="sidebar-motto">“The best gift I can give is myself.”</div></div>
      </aside>

      <div className="main-area">
        <header className="topbar"><button className="mobile-menu" onClick={() => setMenuOpen((open) => !open)} aria-label="Open navigation">{menuOpen ? <X /> : <Menu />}</button><div className="mobile-brand"><CoachPlayerMark compact /></div><div className="topbar-spacer" /><button className="help-button" onClick={() => showToast("Support centre opened.")}><CircleHelp size={18} /><span>Help</span></button><button className="account-button" onClick={() => showToast("Account profile opened.")}><span>TM</span><div><strong>Thabo</strong><small>Admin</small></div><ChevronDown size={15} /></button></header>
        <AnimatePresence>{menuOpen && <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="mobile-nav"><div className="mobile-nav-brand"><CoachPlayerMark /><button onClick={() => setMenuOpen(false)}><X /></button></div>{[...navigation, ...coachingNavigation].map((item) => <button key={item.view} className={view === item.view ? "active" : ""} onClick={() => navigate(item.view)}><item.icon size={18} />{item.label}</button>)}</motion.div>}</AnimatePresence>
        <main className="workspace" key={view}>{renderView()}</main>
      </div>
      <AnimatePresence>{toast && <motion.div key={toast.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 16 }} className="toast"><Check size={18} /><span>{toast.message}</span><button onClick={() => setToast(null)} aria-label="Dismiss notification"><X size={16} /></button></motion.div>}</AnimatePresence>
    </div>
  );
}